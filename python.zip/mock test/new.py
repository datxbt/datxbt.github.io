import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3, os

os.chdir(os.path.dirname(os.path.abspath(__file__)))

# ================= CSDL =================
con = sqlite3.connect("quanly.db")
cur = con.cursor()
cur.execute("""CREATE TABLE IF NOT EXISTS sinhvien(
    ma TEXT PRIMARY KEY, ten TEXT, gioitinh TEXT,
    khoa TEXT, sothich TEXT, diem REAL)""")
con.commit()

# ================= GIAO DIỆN =================
window = tk.Tk()
window.title("Quản lý sinh viên")
window.geometry("900x580")

frm = tk.LabelFrame(window, text="Thông tin sinh viên", padx=10, pady=10)
frm.pack(fill="x", padx=10, pady=5)          # window: dùng pack cho các khung lớn

# --- Cột trái: Entry (bên trong frm: chỉ dùng grid) ---
tk.Label(frm, text="Mã SV:").grid(row=0, column=0, sticky="w")
txtMa = tk.Entry(frm, width=25)
txtMa.grid(row=0, column=1, pady=3)
tk.Label(frm, text="Họ tên:").grid(row=1, column=0, sticky="w")
txtTen = tk.Entry(frm, width=25)
txtTen.grid(row=1, column=1, pady=3)
tk.Label(frm, text="Điểm:").grid(row=2, column=0, sticky="w")
txtDiem = tk.Entry(frm, width=25)
txtDiem.grid(row=2, column=1, pady=3)

# --- Cột phải: Radiobutton / Combobox / Checkbutton ---
tk.Label(frm, text="Giới tính:").grid(row=0, column=2, sticky="w", padx=(30, 5))
gioitinh = tk.StringVar(value="")             # "" = chưa chọn
frmGT = tk.Frame(frm)
frmGT.grid(row=0, column=3, sticky="w")
tk.Radiobutton(frmGT, text="Nam", value="Nam", variable=gioitinh).pack(side="left")
tk.Radiobutton(frmGT, text="Nữ", value="Nữ", variable=gioitinh).pack(side="left")

tk.Label(frm, text="Khoa:").grid(row=1, column=2, sticky="w", padx=(30, 5))
ds_khoa = []
if os.path.exists("khoa.txt"):
    f = open("khoa.txt", encoding="utf-8")
    for dong in f.read().splitlines():
        if dong.strip() != "":
            ds_khoa.append(dong.strip())
    f.close()
cbKhoa = ttk.Combobox(frm, values=ds_khoa, state="readonly", width=25)
cbKhoa.grid(row=1, column=3, sticky="w")

tk.Label(frm, text="Sở thích:").grid(row=2, column=2, sticky="w", padx=(30, 5))
thethao = tk.IntVar()
amnhac = tk.IntVar()
docsach = tk.IntVar()
frmST = tk.Frame(frm)
frmST.grid(row=2, column=3, sticky="w")
tk.Checkbutton(frmST, text="Thể thao", variable=thethao).pack(side="left")
tk.Checkbutton(frmST, text="Âm nhạc", variable=amnhac).pack(side="left")
tk.Checkbutton(frmST, text="Đọc sách", variable=docsach).pack(side="left")


# ================= KIỂM TRA DỮ LIỆU =================
def kiemtra():
    ma = txtMa.get().strip()
    if len(ma) != 6 or ma[0] != "A" or not ma[1:].isdigit():
        messagebox.showerror("Lỗi", "Mã SV phải dạng A + 5 chữ số (VD A45371)")
        return False
    if txtTen.get().strip() == "":
        messagebox.showerror("Lỗi", "Chưa nhập họ tên")
        return False
    try:
        diem = float(txtDiem.get())
        if diem < 0 or diem > 10:
            raise ValueError
    except ValueError:
        messagebox.showerror("Lỗi", "Điểm phải là số từ 0 đến 10")
        return False
    if gioitinh.get() == "":
        messagebox.showerror("Lỗi", "Chưa chọn giới tính")
        return False
    if cbKhoa.get() == "":
        messagebox.showerror("Lỗi", "Chưa chọn khoa")
        return False
    return True


def lay_sothich():                    # -> "Thể thao, Đọc sách"
    ds = []
    if thethao.get() == 1:
        ds.append("Thể thao")
    if amnhac.get() == 1:
        ds.append("Âm nhạc")
    if docsach.get() == 1:
        ds.append("Đọc sách")
    return ", ".join(ds)


def lay_form():                       # tuple 6 giá trị đúng thứ tự cột
    return (txtMa.get().strip(), txtTen.get().strip(), gioitinh.get(),
            cbKhoa.get(), lay_sothich(), float(txtDiem.get()))


# ================= XỬ LÝ =================
def load_data(tu_khoa=""):
    for dong in tree.get_children():
        tree.delete(dong)
    cur.execute("SELECT * FROM sinhvien WHERE ma LIKE ? OR ten LIKE ? ORDER BY ma",
                ("%" + tu_khoa + "%", "%" + tu_khoa + "%"))
    for row in cur.fetchall():
        tree.insert("", "end", iid=row[0], values=row)     # iid = mã
    lblDem.config(text="Tổng: " + str(len(tree.get_children())) + " sinh viên")


def lammoi():
    txtMa.config(state="normal")
    txtMa.delete(0, "end")
    txtTen.delete(0, "end")
    txtDiem.delete(0, "end")
    gioitinh.set("")
    cbKhoa.set("")
    thethao.set(0)
    amnhac.set(0)
    docsach.set(0)
    txtMa.focus()


def them():
    if not kiemtra():
        return
    try:
        cur.execute("INSERT INTO sinhvien VALUES (?, ?, ?, ?, ?, ?)", lay_form())
        con.commit()
    except sqlite3.IntegrityError:
        messagebox.showerror("Lỗi", "Mã sinh viên đã tồn tại!")
        return
    messagebox.showinfo("Thông báo", "Thêm thành công")
    load_data()
    lammoi()


def chon_dong(event=None):
    chon = tree.selection()
    if len(chon) == 0:
        return
    cur.execute("SELECT * FROM sinhvien WHERE ma = ?", (chon[0],))  # đọc lại từ CSDL
    row = cur.fetchone()                                            # (giữ số 0 đầu SĐT)
    if row is None:
        return
    lammoi()
    txtMa.insert(0, row[0])
    txtMa.config(state="readonly")          # không cho sửa khóa chính
    txtTen.insert(0, row[1])
    gioitinh.set(row[2])
    cbKhoa.set(row[3])
    thethao.set(1 if "Thể thao" in row[4] else 0)
    amnhac.set(1 if "Âm nhạc" in row[4] else 0)
    docsach.set(1 if "Đọc sách" in row[4] else 0)
    txtDiem.insert(0, row[5])


def sua():
    if len(tree.selection()) == 0:
        messagebox.showwarning("Chú ý", "Hãy chọn dòng cần sửa")
        return
    if not kiemtra():
        return
    ma, ten, gt, khoa, st, diem = lay_form()
    cur.execute("UPDATE sinhvien SET ten=?, gioitinh=?, khoa=?, sothich=?, diem=? WHERE ma=?",
                (ten, gt, khoa, st, diem, ma))
    con.commit()
    messagebox.showinfo("Thông báo", "Sửa thành công")
    load_data()
    lammoi()


def xoa():
    chon = tree.selection()
    if len(chon) == 0:
        messagebox.showwarning("Chú ý", "Hãy chọn dòng cần xóa")
        return
    if messagebox.askyesno("Xác nhận", "Xóa sinh viên " + chon[0] + "?"):
        cur.execute("DELETE FROM sinhvien WHERE ma = ?", (chon[0],))
        con.commit()
        load_data()
        lammoi()


def tim():
    load_data(txtTim.get().strip())


def thoat():
    if messagebox.askyesno("Thoát", "Bạn có muốn thoát?"):
        con.close()
        window.destroy()


# ================= NÚT + TÌM KIẾM =================
frmNut = tk.Frame(window)
frmNut.pack(pady=4)
tk.Button(frmNut, text="Thêm", width=10, command=them).pack(side="left", padx=3)
tk.Button(frmNut, text="Sửa", width=10, command=sua).pack(side="left", padx=3)
tk.Button(frmNut, text="Xóa", width=10, command=xoa).pack(side="left", padx=3)
tk.Button(frmNut, text="Làm mới", width=10, command=lammoi).pack(side="left", padx=3)
tk.Label(frmNut, text="   Tìm:").pack(side="left")
txtTim = tk.Entry(frmNut, width=20)
txtTim.pack(side="left")
tk.Button(frmNut, text="Tìm", width=8, command=tim).pack(side="left", padx=3)
txtTim.bind("<Return>", lambda e: tim())

# ================= TREEVIEW + THANH CUỘN =================
frmTree = tk.Frame(window)
frmTree.pack(fill="both", expand=True, padx=10, pady=5)
cot = ("ma", "ten", "gioitinh", "khoa", "sothich", "diem")
tieude = ("Mã SV", "Họ tên", "Giới tính", "Khoa", "Sở thích", "Điểm")
dorong = (80, 170, 70, 180, 170, 60)
tree = ttk.Treeview(frmTree, columns=cot, show="headings")
for i in range(len(cot)):
    tree.heading(cot[i], text=tieude[i])
    tree.column(cot[i], width=dorong[i], anchor="w")
sb = ttk.Scrollbar(frmTree, orient="vertical", command=tree.yview)
tree.configure(yscrollcommand=sb.set)
tree.pack(side="left", fill="both", expand=True)
sb.pack(side="right", fill="y")
tree.bind("<<TreeviewSelect>>", chon_dong)

lblDem = tk.Label(window, text="")
lblDem.pack(anchor="w", padx=10)

# ================= MENU + POPUP + NÚT X =================
menubar = tk.Menu(window)
filemenu = tk.Menu(menubar, tearoff=0)
filemenu.add_command(label="Làm mới", command=lammoi)
filemenu.add_separator()
filemenu.add_command(label="Thoát", command=thoat)
menubar.add_cascade(label="File", menu=filemenu)
window.config(menu=menubar)

popup = tk.Menu(window, tearoff=0)
popup.add_command(label="Sửa dòng này", command=sua)
popup.add_command(label="Xóa dòng này", command=xoa)


def hien_popup(event):
    dong = tree.identify_row(event.y)
    if dong != "":
        tree.selection_set(dong)
        popup.tk_popup(event.x_root, event.y_root)
        popup.grab_release()


tree.bind("<Button-3>", hien_popup)
window.protocol("WM_DELETE_WINDOW", thoat)

load_data()
window.mainloop()