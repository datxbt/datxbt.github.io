# <=50kWh = 1800d/kWh
# (51-100)kwh = 1900d/kwh
# (101-200)kwh = 2200d/kwh
# >201kwh = 2800d/kwh
# +10% VAT
import tkinter as tk
from tkinter import messagebox

window = tk.Tk()
window.title("Tính tiền điện")
window.geometry("400x300")

def tinh():
    try:
        data = int(sokwh_entry.get())

        if data < 0:
            messagebox.showerror("Lỗi","Lỗi không được nhập số âm")
            return

        total = 0

        if data <= 50:
            total = data*1800
        elif data <=100:
            total = ((data-50)*1900) + 50*1800
        elif data <=200:
            total = ((data-100)*2200) + 50*1800 + 50*1900
        else:
            total = ((data-200)*2800) + 50*1800 + 50*1900 + 100*2200
        
        formattotal = f"{total:,}" + " đ"
        tiendien_label2.config(text= formattotal)

        VAT = int(total/10)
        formatVAT = f"{VAT:,}" + " đ"
        VAT_label2.config(text= formatVAT)

        tong = total + VAT
        formattong = f"{tong:,}" + " đ"
        tong_label2.config(text= formattong)

    except ValueError:
        messagebox.showerror("Lỗi","Lỗi kiểu dữ liệu")

def xoa():
    sokwh_entry.delete(0, tk.END)
    tiendien_label2.config(text= "")
    VAT_label2.config(text= "")
    tong_label2.config(text= "")
    

mainlabel = tk.Label(master= window, text= "TÍNH TIỀN ĐIỆN", font= ("Arial", 20, "bold"))
mainlabel.grid(column= 0, row= 0, padx= 50, pady= 20, sticky= "S")

sokwh_label = tk.Label(master= window, text= "Số kWh:")
sokwh_label.grid(column= 0, row= 1, padx= 20, pady= 0, sticky= "W")
sokwh_entry = tk.Entry(master=window)
sokwh_entry.grid(column= 0, row= 1, padx= 120, pady= 0, sticky= "W")

tiendien_label = tk.Label(master= window, text= "Tiền điện:")
tiendien_label.grid(column= 0, row= 2, padx= 20, pady= 10, sticky= "W")
tiendien_label2 = tk.Label(master=window, fg= "blue")
tiendien_label2.grid(column= 0, row= 2, padx= 120, pady= 10, sticky= "W")

VAT_label = tk.Label(master= window, text= "Thuế VAT 10%:")
VAT_label.grid(column= 0, row= 3, padx= 20, pady= 0, sticky= "W")
VAT_label2 = tk.Label(master=window, fg = "blue")
VAT_label2.grid(column= 0, row= 3, padx= 120, pady= 0, sticky= "W")

tong_label = tk.Label(master= window, text= "Tổng phải trả:")
tong_label.grid(column= 0, row= 4, padx= 20, pady= 10, sticky= "W")
tong_label2 = tk.Label(master=window, fg = "red", font = "bold")
tong_label2.grid(column= 0, row= 4, padx= 120, pady= 10, sticky= "W")

tinh_button = tk.Button(master= window, width= 9, text= "Tính", command= tinh)
tinh_button.grid(column= 0, row= 5, padx= 120, pady= 10, sticky= "W")
xoa_button = tk.Button(master= window, width= 9, text= "Xóa", command= xoa)
xoa_button.grid(column= 0, row= 5, padx= 192, pady= 10, sticky= "W")

print("program started")

window.mainloop()