
ttk.Checkbutton(master= labelFrame, text= "Thể thao", variable= thethao).grid(row=2, column=3, padx=0, pady=5, sticky="w")