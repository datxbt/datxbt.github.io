import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import sqlite3

# ===================== c) CƠ SỞ DỮ LIỆU =====================
con = sqlite3.connect("quanlysinhvien.db")
cur = con.cursor()
cur.execute("CREATE TABLE IF NOT EXISTS sinhvien(masv TEXT PRIMARY KEY, hoten TEXT, email TEXT, sdt TEXT, gioitinh TEXT, khoa TEXT, sothich TEXT)")
con.commit()

# ===================== a) GIAO DIỆN =====================
window = tk.Tk()
window.title("Quản lý sinh viên")
window.geometry("1000x600")

labelFrame = tk.LabelFrame(master= window, text= "Thông tin sinh viên", padx=10, pady=10)
labelFrame.grid(column=0, row=0, padx=7, pady=7, sticky= "nswe")

masv1 = tk.Label(master= labelFrame, text= "Mã SV:")
masv1.grid(row=0, column=0, padx=0, pady=5, sticky="w")
hoten1 = tk.Label(master= labelFrame, text= "Họ tên:")
hoten1.grid(row=1, column=0, padx=0, pady=5, sticky="w")
email1 = tk.Label(master= labelFrame, text= "Email:")
email1.grid(row=2, column=0, padx=0, pady=5, sticky="w")
sdt1 = tk.Label(master= labelFrame, text= "Số điện thoại:")
sdt1.grid(row=3, column=0, padx=0, pady=5, sticky="w")

masv2 = tk.Entry(master= labelFrame, width= 27)
masv2.grid(row=0, column=1, padx=0, pady=5, sticky="w")
hoten2 = tk.Entry(master= labelFrame, width= 27)
hoten2.grid(row=1, column=1, padx=0, pady=5, sticky="w")
email2 = tk.Entry(master= labelFrame, width= 27)
email2.grid(row=2, column=1, padx=0, pady=5, sticky="w")
sdt2 = tk.Entry(master= labelFrame, width= 27)
sdt2.grid(row=3, column=1, padx=0, pady=5, sticky="w")

sex1 = tk.Label(master= labelFrame, text= "Giới tính:")
sex1.grid(row=0, column=2, padx=40, pady=5, sticky="w")
khoa1 = tk.Label(master= labelFrame, text= "Khoa:")
khoa1.grid(row=1, column=2, padx=40, pady=5, sticky="w")
sothich1 = tk.Label(master= labelFrame, text= "Sở thích:")
sothich1.grid(row=2, column=2, padx=40, pady=5, sticky="w")

gendervar = tk.StringVar(value="")

sex2 = tk.Radiobutton(master= labelFrame, text= "Nam", value= "Nam", variable= gendervar)
sex3 = tk.Radiobutton(master= labelFrame, text= "Nữ", value= "Nữ", variable= gendervar)
sex2.grid(row=0, column=3, padx=0, pady=5, sticky="w")
sex3.grid(row=0, column=3, padx=60, pady=5, sticky="w")

# Đọc khoa.txt
f = open("khoa.txt", encoding= "utf-8")
dskhoa = f.read().splitlines()
f.close()

choice = tk.StringVar(value= "")          # để trống, bắt người dùng phải chọn
khoa2 = ttk.Combobox(labelFrame, textvariable=choice, values= dskhoa, state= "readonly", width=27)
khoa2.grid(row=1, column=3, padx=0, pady=5, sticky="w")

thethao = tk.BooleanVar()
amnhac = tk.BooleanVar()
docsach = tk.BooleanVar()

ttk.Checkbutton(master= labelFrame, text= "Thể thao", variable= thethao).grid(row=2, column=3, padx=0, pady=5, sticky="w")
ttk.Checkbutton(master= labelFrame, text= "Âm nhạc", variable= amnhac).grid(row=2, column=3, padx=80, pady=5, sticky="w")
ttk.Checkbutton(master= labelFrame, text= "Đọc sách", variable= docsach).grid(row=2, column=3, padx=160, pady=5, sticky="w")


# ===================== b) KIỂM TRA DỮ LIỆU =====================
def kiemtra():
    masv = masv2.get().strip()
    hoten = hoten2.get().strip()
    email = email2.get().strip()
    sdt = sdt2.get().strip()

    # Mã SV: chữ A + 5 chữ số, ví dụ A45371
    if len(masv) != 6 or masv[0] != "A" or not masv[1:].isdigit():
        messagebox.showerror("Lỗi", "Mã SV phải có dạng A + 5 chữ số (VD: A45371)")
        return False

    if hoten == "":
        messagebox.showerror("Lỗi", "Họ tên không được để trống")
        return False

    # Email: có 1 dấu @, và sau @ có dấu chấm
    if email.count("@") != 1 or "." not in email.split("@")[1] or email[0] == "@":
        messagebox.showerror("Lỗi", "Email không hợp lệ")
        return False

    if len(sdt) != 10 or not sdt.isdigit() or sdt[0] != "0":
        messagebox.showerror("Lỗi", "Số điện thoại phải gồm 10 chữ số, bắt đầu bằng 0")
        return False

    if gendervar.get() == "":
        messagebox.showerror("Lỗi", "Bạn chưa chọn giới tính")
        return False

    if choice.get() == "":
        messagebox.showerror("Lỗi", "Bạn chưa chọn khoa")
        return False

    return True


# Ghép các sở thích được tick thành 1 chuỗi, ví dụ "Thể thao, Đọc sách"
def lay_sothich():
    ds = []
    if thethao.get():
        ds.append("Thể thao")
    if amnhac.get():
        ds.append("Âm nhạc")
    if docsach.get():
        ds.append("Đọc sách")
    return ", ".join(ds)


# ===================== c), d) XỬ LÝ =====================
def load_data():
    for dong in table.get_children():
        table.delete(dong)
    cur.execute("SELECT * FROM sinhvien")
    for row in cur.fetchall():
        table.insert("", tk.END, iid= row[0], values= row)    # iid = mã SV


def lammoi():
    masv2.config(state= "normal")
    masv2.delete(0, tk.END)
    hoten2.delete(0, tk.END)
    email2.delete(0, tk.END)
    sdt2.delete(0, tk.END)
    gendervar.set("")
    choice.set("")
    thethao.set(False)
    amnhac.set(False)
    docsach.set(False)


def them():
    if kiemtra() == False:
        return
    try:
        cur.execute("INSERT INTO sinhvien VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (masv2.get().strip(), hoten2.get().strip(), email2.get().strip(), sdt2.get().strip(),
                     gendervar.get(), choice.get(), lay_sothich()))
        con.commit()
    except sqlite3.IntegrityError:
        messagebox.showerror("Lỗi", "Mã sinh viên đã tồn tại!")
        return
    messagebox.showinfo("Thông báo", "Thêm thành công")
    load_data()
    lammoi()


def chondong(event):
    chon = table.selection()
    if len(chon) == 0:
        return
    masv = chon[0]
    # Lấy lại từ CSDL để số điện thoại giữ số 0 ở đầu
    cur.execute("SELECT * FROM sinhvien WHERE masv = ?", (masv,))
    row = cur.fetchone()
    if row == None:
        return
    lammoi()
    masv2.insert(0, row[0])
    masv2.config(state= "readonly")          # không cho sửa Mã SV
    hoten2.insert(0, row[1])
    email2.insert(0, row[2])
    sdt2.insert(0, row[3])
    gendervar.set(row[4])
    choice.set(row[5])
    sothich = row[6]
    thethao.set("Thể thao" in sothich)
    amnhac.set("Âm nhạc" in sothich)
    docsach.set("Đọc sách" in sothich)


def sua():
    if len(table.selection()) == 0:
        messagebox.showwarning("Chú ý", "Hãy chọn sinh viên cần sửa")
        return
    if kiemtra() == False:
        return
    cur.execute("UPDATE sinhvien SET hoten = ?, email = ?, sdt = ?, gioitinh = ?, khoa = ?, sothich = ? WHERE masv = ?",
                (hoten2.get().strip(), email2.get().strip(), sdt2.get().strip(),
                 gendervar.get(), choice.get(), lay_sothich(), masv2.get()))
    con.commit()
    messagebox.showinfo("Thông báo", "Sửa thành công")
    load_data()
    lammoi()


def xoa():
    chon = table.selection()
    if len(chon) == 0:
        messagebox.showwarning("Chú ý", "Hãy chọn sinh viên cần xóa")
        return
    masv = chon[0]
    if messagebox.askyesno("Xác nhận", "Bạn có chắc muốn xóa sinh viên " + masv + "?"):
        cur.execute("DELETE FROM sinhvien WHERE masv = ?", (masv,))
        con.commit()
        load_data()
        lammoi()


def thoat():
    if messagebox.askyesno("Thoát", "Bạn có muốn thoát chương trình?"):
        con.close()
        window.destroy()


# ===================== NÚT =====================
thembutton = tk.Button(master= window, text= "Thêm", width= 10, command= them)
suabutton = tk.Button(master= window, text= "Sửa", width= 10, command= sua)
xoabutton = tk.Button(master= window, text= "Xóa", width= 10, command= xoa)
lammoibutton = tk.Button(master= window, text= "Làm mới", width= 10, command= lammoi)

thembutton.grid(column=0, row=1, padx=250, pady=0, sticky="w")
suabutton.grid(column=0, row=1, padx= 350, pady=0, sticky="w")
xoabutton.grid(column=0, row=1, padx=450, pady=0, sticky="w")
lammoibutton.grid(column=0, row=1, padx=(550,0), pady=0, sticky="w")

# ===================== TREEVIEW + THANH CUỘN =====================
table = ttk.Treeview(master= window, columns= ("masv", "hoten", "email", "sdt", "gioitinh", "khoa", "sothich"), show= "headings")
table.heading("masv", text= "Mã SV")
table.heading("hoten", text= "Họ tên")
table.heading("email", text= "Email")
table.heading("sdt", text= "SĐT")
table.heading("gioitinh", text= "Giới tính")
table.heading("khoa", text= "Khoa")
table.heading("sothich", text= "Sở thích")
table.column("masv", width= 70)
table.column("hoten", width= 150)
table.column("email", width= 170)
table.column("sdt", width= 95)
table.column("gioitinh", width= 65)
table.column("khoa", width= 170)
table.column("sothich", width= 150)
table.grid(column=0, row=2, padx=(7,0), pady=10, sticky="we")

thanhcuon = ttk.Scrollbar(master= window, orient= "vertical", command= table.yview)
table.configure(yscrollcommand= thanhcuon.set)
thanhcuon.grid(column=1, row=2, pady=10, sticky="ns")

table.bind("<<TreeviewSelect>>", chondong)

# ===================== e) MENU + POPUP =====================
menubar = tk.Menu(master= window)
filemenu = tk.Menu(master= menubar, tearoff= 0)
filemenu.add_command(label= "Làm mới", command= lammoi)
filemenu.add_separator()
filemenu.add_command(label= "Thoát", command= thoat)
menubar.add_cascade(label= "File", menu= filemenu)
window.config(menu= menubar)

popup = tk.Menu(master= window, tearoff= 0)
popup.add_command(label= "Xóa sinh viên này", command= xoa)


def hien_popup(event):
    dong = table.identify_row(event.y)       # dòng nằm dưới con trỏ chuột
    if dong != "":
        table.selection_set(dong)
        popup.tk_popup(event.x_root, event.y_root)
        popup.grab_release()


table.bind("<Button-3>", hien_popup)
window.protocol("WM_DELETE_WINDOW", thoat)    # bấm nút X cũng hỏi

load_data()
window.mainloop()
