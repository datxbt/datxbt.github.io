class myException(RuntimeError):
    def __init__(self, abc):
        self.args = abc
        print('Co loi: ' + abc)

def testcustomexception():
    try:
        print('before')
        raise myException('Loi tu dinh nghia')
    except myException as e:
        print(e.args)

testcustomexception()