import os

cmd = 'date'

os.system(cmd)

cmd = "notepad"

os.system(cmd)

cpucount = os.cpu_count()
print(cpucount)

obj = os.scandir()

for entry in obj:
    if entry.is_dir() or entry.is_file():
        print(entry.name)

obj.close()