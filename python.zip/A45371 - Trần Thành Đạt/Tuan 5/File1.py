f = open('data.txt', 'w')

for i in range (5):
    f.write('Lap trinh Frontend\n')
    i += 1

f.close()

f = open('data.txt', 'r')
data = f.read()

print(data)

f.close()