try:
    list = [1,2,3,4]
    age = 3
    print(age3)
    print(list[5])
    print(age / 0)


except NameError:
    print('Bien chua duoc khai bao')

except ZeroDivisionError:
    print('Co loi xay ra /0')

except IndexError:
    print('Loi tran mang')

else:
    print('Chuong trinh thuc hien thanh cong')

finally:
    print('ket thuc chuong trinh')
