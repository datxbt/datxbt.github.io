import os

# Ghi file: dong file truoc khi mo lai de doc
f = open('data.txt', 'w')
noidung = input()
f.write(noidung)
f.close()

f = open('data.txt', 'r')
data = f.read()   # read() phai co dau ngoac, thieu () se in ra dia chi ham
print(data)

print('name: ', f.name)
print('mode: ', f.mode)
print('closed: ', f.closed)

f.close()
print('closed: ', f.closed)

# os.rename bao loi neu 'newdata.txt' da ton tai (tren Windows),
# os.replace thi ghi de file cu
os.replace('data.txt', 'newdata.txt')
