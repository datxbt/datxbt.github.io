age = 3
try:
    print(age)
except NameError:   # ghi ten loai loi sau except
    print('Bien chua duoc khai bao!')
else:
    print('Chuong trinh thuc hien thanh cong')
finally:
    print('Ket thuc chuong trinh')