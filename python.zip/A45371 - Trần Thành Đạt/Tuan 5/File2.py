ten_file = input('Nhap ten file: ') + '.txt'

with open(ten_file, 'w') as f:
    for _ in range(5):
        f.write('Tony lap trinh\n')
        f.write('Lap trinh Hai\n')

with open(ten_file, 'r') as f:
    print(f.read())

dem_tony = 0
dem_hai = 0
with open(ten_file, 'r') as f:
    for dong in f:
        dong = dong.strip()
        if dong.startswith('Tony'):
            dem_tony += 1
        if dong.endswith('Hai'):
            dem_hai += 1

print('So dong bat dau bang Tony:', dem_tony)
print('So dong ket thuc bang Hải:', dem_hai)