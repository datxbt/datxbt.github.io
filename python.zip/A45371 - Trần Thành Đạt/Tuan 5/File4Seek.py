ten_file = input('Nhap ten file: ')

f = open(ten_file,'w')
for i in range(5):
    f.write("Lap trinh Hai, Lap trinh Tony\n")
f.close()

# dung bien ten_file, KHONG dat trong dau nhay ('ten_file' la mot chuoi co dinh)
f = open(ten_file, 'r')
data = f.read(20)
print(data)
print('vi tri hien tai: ',f.tell())

f.seek(10)
print('vi tri con tro sau khi dich 10 byte: ', f.tell())
f.close()