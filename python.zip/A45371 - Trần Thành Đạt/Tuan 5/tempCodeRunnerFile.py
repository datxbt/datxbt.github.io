list = [1,2,3,4]
age = 3

try:
    age = 3
    print(list[5])
    age / 0
except:
    NameError(print('Bien chua duoc khai bao'))
finally:
    print('ket thuc chuong trinh')
