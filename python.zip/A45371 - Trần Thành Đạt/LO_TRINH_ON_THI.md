# Lộ trình ôn thi — Ứng dụng Python (trọng tâm Tkinter)

> Thầy đã nhắc: **trọng tâm thi là Tkinter**. Lộ trình dồn khoảng 80% thời gian cho Tkinter (Tuần 8 → 11). Phần Python cơ bản chỉ ôn những gì cần để viết được form Tkinter.

**Tài liệu kèm theo:**
- [On thi/khung_tkinter_sqlite.py](On%20thi/khung_tkinter_sqlite.py): ứng dụng mẫu đầy đủ (form, validate, Combobox đọc từ file, thêm/sửa/xóa SQLite, Treeview, menu, popup chuột phải). Đã chạy thử. **Đây là file quan trọng nhất: luyện gõ lại đến khi tự viết được trong 15–20 phút.**
- Trang trắc nghiệm warm-up: https://claude.ai/artifact/Y6Rm1VSXuxc1y7NKCmXNh4 (bấm chip "Trọng tâm Tkinter").
- PDF hướng dẫn và lab của thầy trong thư mục `UDPython`.

| Buổi | Nội dung | Tài liệu |
|---|---|---|
| 1 | Python cần cho Tkinter (nén) | Tuần 1–6 |
| 2 | Khung cửa sổ, Label, Entry, Button, messagebox | Tuần 8 |
| 3 | Bố cục `grid` / `pack` / `place`, Frame, LabelFrame | Tuần 8–9, Lab Design Basic 4 |
| 4 | Biến điều khiển, widget lựa chọn, Text, Toplevel | Tuần 9 |
| 5 | Validate form, đọc file vào Combobox, ghi file | Tuần 10, Lab Registration Form 1 |
| 6 | Menu, popup menu, viết ứng dụng dạng class | Tuần 10 |
| 7 | Treeview | Tuần 10 |
| 8 | SQLite + form: insert có validate | Tuần 11, Lab Insert 1 |
| 9 | CRUD đầy đủ: Treeview + SQLite + popup | Tuần 11, file khung |
| 10 | Thi thử 2 đề Tkinter, bấm giờ | — |

Thiếu thời gian thì làm theo thứ tự ưu tiên: **Buổi 5 → 9 → 3 → 7 → 6**, rồi đến các buổi còn lại.

---

## Buổi 1 — Python cần cho Tkinter (1 buổi là đủ)
Chỉ ôn những thứ sẽ dùng trong code Tkinter:
- Ép kiểu `int()` / `float()` và chuỗi: `strip()`, `isdigit()`, `"@" in email`, `len()`, f-string.
- `if` / `elif` / `return` sớm (đây chính là khung của hàm validate).
- List và vòng `for`: đọc file thành list, duyệt `cur.fetchall()`.
- Hàm, biến `global` (ví dụ biến `selected_id`), `lambda` (truyền tham số cho `command`).
- `with open(..., encoding="utf-8")`, `try/except` (bắt `ValueError` khi ép kiểu, `sqlite3.Error`).
- Class, `__init__`, `self` (bài popup menu của thầy viết dạng class).
- Các lỗi đã sửa trong code cũ: giai thừa `range(1, a + 1)`, `f.read()` phải có `()`, `super().__init__`.

Làm nhanh phần warm-up các chủ đề không phải Tkinter, sai câu nào thì xem lại file của tuần đó.

## Buổi 2 — Khung cửa sổ và widget cơ bản (Tuần 8)
**Xem lại:** `Tuan 8/tkinterbasic1.py`, `tkinterbasic2.py` (máy tính dùng `lambda`), `tkinterbasic2_2.py` (`pack` + `resizable`).

```python
from tkinter import *
from tkinter import messagebox
ws = Tk()
ws.title("Tiêu đề")
ws.geometry("400x300")          # chuỗi "rộngxcao"
ws.resizable(False, False)
ws.config(bg="#0B5A81")
lbl = Label(ws, text="Họ tên:", font=("Times", 14), bg="white", fg="black")
txt = Entry(ws, width=30)       # Entry(ws, show="*") cho mật khẩu
btn = Button(ws, text="OK", command=xuly)   # KHÔNG viết xuly()
ws.mainloop()
```
Phải thuộc:
- Entry: `get()`, `delete(0, END)`, `insert(0, "...")`. Label: `config(text=...)`.
- `command=ham` (không có ngoặc). Cần truyền tham số thì dùng `command=lambda: tinh("+")`.
- `messagebox.showinfo / showwarning / showerror` (thông báo); `askyesno` trả về `True/False`, `askquestion` trả về `"yes"/"no"`.
- `ws.destroy()` để đóng cửa sổ.

**Bài luyện:** máy tính 2 số (2 Entry, 4 nút + − × ÷, Label kết quả). Bắt lỗi nhập chữ bằng `try/except ValueError` và lỗi chia cho 0.

## Buổi 3 — Bố cục (rất hay mất điểm)
**Xem lại:** `tuan 9/new2.py`, `tuan 10/tuan10.py` (Frame + LabelFrame); PDF `BT Lab Tkinter Design Basic 4.pdf`.

| Cách | Dùng khi | Tham số chính |
|---|---|---|
| `grid(row, column)` | Form dạng bảng nhãn–ô nhập (**dùng nhiều nhất**) | `sticky=W/E/N/S`, `columnspan`, `rowspan`, `padx`, `pady` |
| `pack()` | Xếp nối tiếp: hàng nút, khung lớn | `side=LEFT/TOP`, `fill=X/Y/BOTH`, `expand=True` |
| `place(x, y)` | Đặt theo tọa độ pixel | `x`, `y`, `relx`, `rely` |

- **Không trộn `pack` và `grid` trong cùng một khung chứa** (báo lỗi TclError). Muốn kết hợp thì chia ra các `Frame`: mỗi Frame dùng một kiểu bố cục.
- `row` và `column` đánh số từ 0. `sticky=W` để căn trái các Label.
- `LabelFrame(ws, text="Giới tính")` tạo khung có tiêu đề để nhóm các Radiobutton.

**Bài luyện:** vẽ lại tất cả form trong *Design Basic 4* mà không mở code mẫu, mỗi form 15 phút.

## Buổi 4 — Biến điều khiển và widget lựa chọn (Tuần 9)
**Xem lại:** `tuan 9/entrywidget.py` (StringVar), `btvn.py` (đã sửa), `new.py` (Toplevel), `../tkintertextwidget.py`.

- `StringVar / IntVar / BooleanVar`: `.get()`, `.set()`; `Entry(ws, textvariable=var)`.
- **Radiobutton:** cả nhóm dùng **chung một** `variable`, mỗi nút một `value` khác nhau.
- **Checkbutton:** **mỗi nút** có một `IntVar` riêng (tick vào là 1, bỏ tick là 0).
- **OptionMenu:** `OptionMenu(ws, var, *countries)` (dấu `*` để bung list ra).
- **ttk.Combobox:** `ttk.Combobox(ws, values=countries, state="readonly")`, lấy giá trị bằng `.get()`, gán bằng `.set()`.
- **Text** (nhiều dòng): lấy hết bằng `t.get("1.0", END)`, xóa hết bằng `t.delete("1.0", END)`. Chỉ số dạng `"dòng.cột"`, dòng tính từ 1.
- **Listbox:** `insert(END, x)`, `curselection()`. **Spinbox:** `Spinbox(ws, from_=1, to=10)` (`from_` có gạch dưới vì `from` là từ khóa).
- **Toplevel(ws):** mở cửa sổ con. Không tạo `Tk()` thứ hai.

**Bài luyện:** form khảo sát có Radiobutton, 3 Checkbutton, Combobox, Text nhận xét. Nút "Xem" mở Toplevel hiển thị lại toàn bộ dữ liệu đã nhập.

## Buổi 5 — Validate form, đọc/ghi file (phần thầy hay cho thi)
**Xem lại:** `tuan 10/tuan10.py` (hàm `validateform`); PDF `Huong dan cac buoc validate form trong Tkinter.pdf`, `Huong dan validate form & ghi file trong Tkinter.pdf`, `BT Lab Tkinter Registration Form 1.pdf`.

Khung hàm validate. Thuộc lòng thứ tự: kiểm tra từng ô, gặp lỗi thì báo rồi `return` luôn.
```python
def validate():
    if txtName.get().strip() == "":
        messagebox.showerror("Lỗi", "Bạn cần nhập họ tên!"); return False
    if "@" not in txtEmail.get():
        messagebox.showerror("Lỗi", "Email không hợp lệ!"); return False
    if not txtMobile.get().isdigit() or len(txtMobile.get()) != 10:
        messagebox.showerror("Lỗi", "Số điện thoại phải gồm 10 chữ số!"); return False
    if var.get() == "":
        messagebox.showerror("Lỗi", "Bạn cần chọn giới tính!"); return False
    if txtPassword.get() != txtConfirm.get():
        messagebox.showerror("Lỗi", "Mật khẩu xác nhận không khớp!"); return False
    return True
```
- Đọc `countries.txt` vào list: `[d.strip() for d in f if d.strip()]`.
- Ghi file: mỗi trường một dòng, dùng `with open(ten + ".txt", "w", encoding="utf-8")`.
- Hàm `clearForm()` xóa trắng mọi ô và đặt lại `var.set("")`. Hàm `quit()` hỏi `askyesno` trước khi `destroy()`.
- Muốn Radiobutton ban đầu chưa chọn gì: `var = StringVar(value="")`.

**Bài luyện:** làm lại Registration Form 1 (họ tên, email, SĐT, giới tính, quốc gia đọc từ file, mật khẩu ×2), validate đủ 7 trường, hợp lệ thì ghi ra file `.txt`. Bấm giờ 40 phút.

## Buổi 6 — Menu, popup menu, ứng dụng dạng class
**Xem lại:** `tuan 10/form.py` (menubar), `popup.py` (class + popup); PDF `Huong dan su dung Popup Menu trong Tkinter.pdf`.

```python
menubar = Menu(ws)
filemenu = Menu(menubar, tearoff=0)        # tearoff=0 bỏ dòng gạch đứt đầu menu
filemenu.add_command(label="Mới", command=moi)
filemenu.add_separator()
filemenu.add_command(label="Thoát", command=thoat)
menubar.add_cascade(label="File", menu=filemenu)
ws.config(menu=menubar)

popup = Menu(ws, tearoff=0)
def hien_popup(event):
    try:
        popup.tk_popup(event.x_root, event.y_root)
    finally:
        popup.grab_release()
ws.bind("<Button-3>", hien_popup)          # Button-3 = chuột phải
```
- Hàm gắn bằng `bind` phải nhận tham số `event`. Hàm gắn vào `command` thì không nhận tham số.
- Sự kiện hay gặp: `<Button-1>` (chuột trái), `<Button-3>` (chuột phải), `<Return>` (phím Enter), `<KeyRelease>`, `<<TreeviewSelect>>`, `<<ComboboxSelected>>`.
- Viết dạng class: tạo `self.root = Tk()` trong `__init__`, widget lưu thành `self.txtName` để các phương thức khác dùng được.
- `ws.protocol("WM_DELETE_WINDOW", thoat)`: bấm dấu X ở góc cửa sổ cũng chạy hàm hỏi xác nhận.

**Bài luyện:** viết lại `popup.py` từ đầu, thêm menubar File / Trợ giúp. Mục "Giới thiệu" hiện `showinfo`.

## Buổi 7 — Treeview
**Xem lại:** `tuan 10/treeview.py`, `../sqlitetreeview.py`; PDF `Huong dan liet ke du lieu len TreeView trong Tkinter.pdf`.

```python
tree = ttk.Treeview(ws, columns=("id", "ten"), show="headings")   # show="headings" ẩn cột #0
tree.heading("id", text="ID"); tree.column("id", width=50, anchor=CENTER)
tree.insert("", END, values=(1, "An"))
for i in tree.get_children(): tree.delete(i)                      # xóa hết dòng
sb = ttk.Scrollbar(ws, orient=VERTICAL, command=tree.yview)
tree.configure(yscrollcommand=sb.set)
tree.bind("<<TreeviewSelect>>", chon)
def chon(event):
    values = tree.item(tree.selection()[0])["values"]
```
- Lưu ý: Treeview tự chuyển chuỗi trông giống số thành số, ví dụ SĐT `"0912..."` mất số 0 ở đầu. Khi đổ lại lên form, nhớ dùng `str()` và kiểm tra lại.

**Bài luyện:** dùng vòng lặp tạo 30 dòng dữ liệu mẫu, có Scrollbar. Chọn một dòng thì đổ dữ liệu của dòng đó lên các Entry.

## Buổi 8 — SQLite + form: thêm có validate
**Xem lại:** `tuan 11/sqlite.py`; PDF `Huong dan insert du lieu SQLite trong Tkinter.pdf`, `Huong dan insert SQLite validate form voi Tkinter 2025.pdf`, `BT Lab Tkinter Insert 1.pdf`.
- `connect` → `cursor` → `CREATE TABLE IF NOT EXISTS` → `execute(sql, (tham_so,))` → **`commit()`**.
- Tham số dùng `?` (MySQL dùng `%s`). Tuple một phần tử phải có dấu phẩy: `(x,)`.
- Bọc thao tác CSDL trong `try/except sqlite3.Error as e` và báo lỗi bằng `showerror`.

**Bài luyện:** Lab Insert 1: form đăng ký, validate, hợp lệ thì insert vào bảng `nhanvien` rồi `clearForm()`.

## Buổi 9 — CRUD đầy đủ (bài tổng hợp)
**Xem lại:** `../sqlitetreeview.py`, PDF `Huong dan load du lieu tu CSDL len Treeview trong Tkinter.pdf`, và **[On thi/khung_tkinter_sqlite.py](On%20thi/khung_tkinter_sqlite.py)**.

Luồng phải nắm: `load_data()` (xóa Treeview → SELECT → insert từng dòng) · `them()` (validate → INSERT → commit → load_data → clear_form) · `chon_dong(event)` (lấy values → đổ lên form → nhớ `selected_id`) · `sua()` / `xoa()` (UPDATE / DELETE theo id, xóa thì hỏi `askyesno`) · tìm kiếm bằng `LIKE ?` với `"%" + kw + "%"`.

**Bài luyện:** đọc hiểu file khung, sau đó **đóng file lại và tự gõ** một bản quản lý sản phẩm (mã, tên, giá, loại) có thêm ô tìm kiếm theo tên.

## Buổi 10 — Thi thử (mỗi đề 90 phút, không xem code cũ)
**Đề 1 — Đăng ký sinh viên:** form Mã SV, Họ tên, Email, SĐT, Giới tính (Radiobutton), Khoa (Combobox đọc từ `khoa.txt`), Sở thích (3 Checkbutton). Validate đầy đủ. Hợp lệ thì lưu vào SQLite và hiển thị trên Treeview. Có menu File → Thoát (hỏi xác nhận).

**Đề 2 — Quản lý món ăn quán café:** CRUD món (tên, giá, loại). Treeview có Scrollbar. Chọn dòng thì đổ lên form. Popup chuột phải có Sửa / Xóa. Ô tìm kiếm. Giá phải là số dương (bắt `ValueError`).

**Tự chấm:** chạy được ngay không? Có `commit()` chưa? Treeview có làm mới sau mỗi thao tác không? Form có xóa trắng sau khi thêm không? Có hỏi xác nhận khi xóa hoặc thoát không?

---

## Lỗi Tkinter hay gặp khi thi
1. `command=ham()` có ngoặc → hàm chạy ngay lúc tạo nút.
2. Trộn `pack` và `grid` trong cùng một khung chứa.
3. Radiobutton không có `variable` chung; Checkbutton dùng chung một biến.
4. Viết `x = Entry(...).grid(...)` → `x` là `None` (vì `grid()` trả về `None`). Phải tạo widget trước, gọi `grid` ở dòng sau.
5. Quên `ws.mainloop()`; tạo hai cửa sổ `Tk()` thay vì dùng `Toplevel`.
6. Hàm gắn bằng `bind` thiếu tham số `event`.
7. Quên `con.commit()`; viết `(id)` thay vì `(id,)`.
8. Không xóa Treeview trước khi load lại → dữ liệu bị nhân đôi.
9. Lấy giá trị Text bằng `get()` không có chỉ số → phải là `get("1.0", END)`.
10. Đặt tên biến trùng tên widget, ví dụ `Label = Label(...)`, làm mất class `Label`.

## Checklist trước ngày thi
- [ ] Tự gõ khung cửa sổ, `grid` form nhãn–ô nhập trong 10 phút
- [ ] Radiobutton, Checkbutton, Combobox, OptionMenu, Text: tạo được và lấy được giá trị
- [ ] Hàm validate đủ các kiểu: rỗng, email, số, độ dài, mật khẩu khớp
- [ ] Đọc file vào Combobox, ghi dữ liệu form ra file
- [ ] Menubar, popup chuột phải, `askyesno` khi thoát
- [ ] Treeview: tạo cột, insert, xóa hết, chọn dòng, Scrollbar
- [ ] SQLite thêm/sửa/xóa/tìm kiếm + reload Treeview
- [ ] Tự gõ lại `khung_tkinter_sqlite.py` trong 20 phút
- [ ] Đạt ≥ 85% các chủ đề Tkinter trên trang trắc nghiệm
