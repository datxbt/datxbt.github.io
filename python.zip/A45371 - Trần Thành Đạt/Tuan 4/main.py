import hinhhoc as hh
import hinhhocnangcao as hhnc
import thuvientinhtoan as tvtt


print(hh.DienTichHinhChuNhat(5, 3))
print(hh.DienTichHinhTron(5))
print(hh.DienTichHinhThang(5, 7, 4))
print(hh.DienTichHinhTamGiacVuong(3, 4))
print(hh.DienTichHinhThoi(6, 8))
print(hh.DienTichHinhTamGiacCan(5, 4))
print(hh.DienTichHinhBinhHanh(6, 5))



print(hhnc.chuvihinhbinhhanh(5, 3, 4))
print(hhnc.dientichhinhbinhhanh(5, 3, 4))

print(hhnc.chuvihinhtru(5))
print(hhnc.dientichhinhtru(5, 10))

print(hhnc.chuvihinhthoi(6))
print(hhnc.dientichhinhthoi(8, 10))

print(hhnc.chuvihinhngugiacdeu(4))
print(hhnc.dientichhinhngugiacdeu(4, 5))

print(hhnc.chuvihinhthangcan(5, 9, 4))
print(hhnc.dientichhinhthangcan(5, 9, 6))


print(tvtt.tong(5, 3))
print(tvtt.hieu(5, 3))
print(tvtt.tich(5, 3))
print(tvtt.thuong(5, 3))

print(tvtt.dientichhinhtru(5, 10))
print(tvtt.dientichhinhvuong(5, 5))
print(tvtt.lapphuong(4))
print(tvtt.giaithua(5))