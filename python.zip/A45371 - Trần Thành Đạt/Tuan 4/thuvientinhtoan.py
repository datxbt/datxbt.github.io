def giaithua(a):
    total = 1
    # range(1, a + 1) de lay ca so a (range khong lay gia tri stop)
    for i in range(1, a + 1):
        total *= i
    return total

def tong(a,b):
    return a+b

def hieu(a,b):
    return a-b

def tich(a,b):
    return a*b

def thuong(a,b):
    return a/b

def dientichhinhtru(r,h):
    return 2*3.14*r*(r+h)

def dientichhinhvuong(a,b):
    return a*b

def lapphuong(a):
    return a*a*a