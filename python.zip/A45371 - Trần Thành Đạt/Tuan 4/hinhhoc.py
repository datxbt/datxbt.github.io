def DienTichHinhChuNhat(a,b):
    return a*b

def DienTichHinhTron(r):
    return r*r*3.14

def DienTichHinhThang(a,b,h):
    return ((a+b)*h)/2

def DienTichHinhTamGiacVuong(a,b):
    return 0.5*a*b

def DienTichHinhThoi(d1,d2):
    return 0.5*d1*d2

def DienTichHinhTamGiacCan(a,h):
    return 0.5*a*h

def DienTichHinhBinhHanh(a,h):
    return a*h
