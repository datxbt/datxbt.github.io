import tkinter as tk
from tkinter import ttk
import MySQLdb

root = tk.Tk()
root.title('Treeview demo - Thầy Cường Lập Trình Python FullStack 2022 !')
root.geometry('650x500')

# columns
columns = ('#1', '#2', '#3', '#4', '#5')

tree = ttk.Treeview(root, columns=columns, show='headings')

# define headings
tree.heading('#1', text='Mã')
tree.heading('#2', text='Họ tên')
tree.heading('#3', text='Lương')
tree.heading('#4', text='Năm sinh')
tree.heading('#5', text='Địa chỉ')

# danh sách thông tin nhân viên
listEmployees = []

# method này dùng để kết nối CSDL rồi load dữ liệu lên Tree
def loadDataIntoTree():
    listEmployees.clear()
    tree.delete(*tree.get_children())

    # Open database connection
    db = MySQLdb.connect("localhost", "root", "", "quanlynhanvien")
    # prepare a cursor object using cursor() method
    cursor = db.cursor()

    # execute SQL query using execute() method.
    cursor.execute("SELECT ma, hoten, luong, namsinh, diachi FROM nhanvien")

    for ma, hoten, luong, namsinh, diachi in cursor.fetchall():
        row = [ma, hoten, luong, namsinh, diachi]
        listEmployees.append(row)

    # adding data to the treeview
    for employee in listEmployees:
        tree.insin listEmployees:
        tree.insert('', tk.END, values=employee)

# gọi hàm để load dữ liệu lên treeview
loadDataIntoTree()

tree.grid(row=0, column=0, sticky='nsew')

# add a scrollbar
scrollbar = ttk.Scrollbar(root, orient=tk.VERTICAL, command=tree.yview)
tree.configure(yscroll=scrollbar.set)
scrollbar.grid(row=0, column=1, sticky='ns')

# run the app
root.mainloop()