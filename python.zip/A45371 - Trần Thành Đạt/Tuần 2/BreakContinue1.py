n = int(input('Nhap so:'))
giaithua = 1
while n > 0:
    giaithua = giaithua * n
    n -= 1
print(giaithua)

n = 300
while n<500:
    if n == 350:
        n += 1
        continue
    elif n == 400:
        pass
    elif n % 7 == 0:
        print(n)
    n += 1


