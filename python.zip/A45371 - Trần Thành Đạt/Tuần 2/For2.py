tong = 0
for i in range(200,600):
    if i % 3 == 0:
        tong += i
print(tong)

tong = 0
for i in range(50,100):
    if i % 5 == 0:
        tong += i
print(tong)