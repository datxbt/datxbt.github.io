#Bai12
tong = 0
tongbinhphuong = 0

for i in range(1, 101):
    tong = tong + i
    tongbinhphuong = tongbinhphuong + i**2

    # b
    if i == 70:
        pass

    # a
    if i == 50:
        break

print(tong)
print(tongbinhphuong)


#Bai2
n = 0
while n < 200:
    if n % 3 == 0:
        n += 1
        continue
    else: n += 1
    if n >= 150:
        break
    print(n-1)