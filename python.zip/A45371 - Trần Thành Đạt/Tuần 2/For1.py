tong = 0
tongbinhphuong = 0
for i in range(101):
    tong = tong + i
    tongbinhphuong = tongbinhphuong + i*i

print(tong)
print(tongbinhphuong)

tong = 0
for i in range(101):
    tong += i
    tong /= 100
print(tong)

x = int(input("Enter a number: "))
giaithua = 1
for i in range(1,x + 1):
    giaithua = giaithua * i
print(giaithua)