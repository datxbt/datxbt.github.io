# Dat ten bien la "ds" thay vi "list" de khong de len ham list() co san
ds = list(range(1,11))
print(ds)
print(sum(ds))
print(len(ds))
print(max(ds))
print(min(ds))
print(sorted(ds))
ds.remove(2)
print(ds)
del ds
# Sau khi del, bien ds khong con ton tai -> dung den se bao NameError
try:
    print(ds)
except NameError:
    print('ds da bi xoa')
