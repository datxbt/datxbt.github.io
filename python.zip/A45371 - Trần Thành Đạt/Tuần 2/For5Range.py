x = int(input('Nhap so:'))
for i in range(1,11):
    print(str(x) + '*' + str(i) + ' = ' + str(i*x))

for i in range(1,x,2):
    print(i)