# Dat ten bien la "ds" thay vi "list" de khong de len ham list() co san
ds = []
for i in range(5):
    ds.append(input("Nhap mon:"))

print(ds)
print(ds[4])
for i in range(5):
    print(ds[i])
ds[3] = "ghe hap sa"
print(ds)
del ds[1]
print(ds)
if "tom hum bo lo pho mai" in ds:
    print('"tom hum bo lo pho mai" co trong list')
else: print('"tom hum bo lo pho mai" khong co trong list')
ds.append("cua rang me")
list2 = ['tom mu ni bo lo pho mai', 'muc mot nang nuong BBQ', 'nhum bien nuong mo hanh']
list3 = ds + list2
print(sorted(list3))
