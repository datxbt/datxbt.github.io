# Dat ten bien la "ds" thay vi "list" de khong de len ham list() co san
ds = [125,43253,4363,234,23426,333,412,33,222,11]
#for i in range(10):
#    ds.append(input())
list2 = [679,675,64,3,78,6,3425,75,6453,22,55]
ds += list2
for i in range(5):
    print(ds)

if 20 in ds:
    print('20 co trong list')
else: print('20 khong co trong list')

print(ds[2])

print(ds[1:3])

print(ds[-1:-6:-1])

print(sum(ds))
print(min(ds))
print(max(ds))
print(sum(ds)/len(ds))

