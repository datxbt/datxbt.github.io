i=0
tong=0
while i<100:
    i=i+1
    tong+=i
print(tong)

i=20
while i<50:
    i=i+1
    if i % 3 == 0:
        print(i)