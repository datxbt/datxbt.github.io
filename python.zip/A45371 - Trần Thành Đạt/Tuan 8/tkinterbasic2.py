
import tkinter as tk
from tkinter import messagebox

window = tk.Tk()
window.title("Login")
window.geometry("400x300")

# Heading
tk.Label(
    window,
    text="Please Login",
    font=("Arial", 16)
).grid(row=0, column=0, columnspan=2,
       padx=10, pady=15, sticky="w")

# Username
tk.Label(window, text="Username:", font=("Arial", 12)).grid(
    row=1, column=0, padx=10, pady=5, sticky="w"
)

username = tk.Entry(window, width=30, font=("Arial", 12))
username.insert(0, "Robo")
username.grid(row=1, column=1, padx=5, pady=5)

# Password
tk.Label(window, text="Password:", font=("Arial", 12)).grid(
    row=2, column=0, padx=10, pady=5, sticky="w"
)

password = tk.Entry(window, width=30, font=("Arial", 12), show="*")
password.grid(row=2, column=1, padx=5, pady=5)

# Login function
def login():
    messagebox.showinfo("Login", f"Welcome, {username.get()}!")

# Login button
tk.Button(
    window, text="Login", font=("Arial", 12),
    command=login
).grid(row=3, column=0, padx=10, pady=8, sticky="w")

# Delete User button
tk.Button(
    window, text="Delete User", fg="red",
    font=("Arial", 12),
    command=lambda: username.delete(0, tk.END)
).grid(row=4, column=0, padx=10, pady=3, sticky="w")

window.mainloop()
