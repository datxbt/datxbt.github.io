import tkinter as tk
window = tk.Tk()
window.title("Hello Python")
window.geometry("300x200")

label = tk.Label(master=window, fg="red", text="This is Label widget", font=20)
label.grid(padx=60, pady=20)
button = tk.Button(master=window, fg="blue", text="This is Button widget")
button.grid(padx=60, pady=10)
entry = tk.Entry(master=window, width=20, font=20)
entry.grid(padx=60, pady=10)

window.mainloop()