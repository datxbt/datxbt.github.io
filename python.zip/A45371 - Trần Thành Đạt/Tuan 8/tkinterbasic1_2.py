
import tkinter as tk

window = tk.Tk()
window.title("Hello Python")
window.geometry("370x280")

label = tk.Label(
    window,
    text="This is Label widget",
    fg="red",
    font=("Arial", 20)
)
label.pack(pady=(55, 25))

button = tk.Button(
    window,
    text="This is Button widget",
    fg="blue",
    command=lambda: open_form()
)
button.pack(pady=5)

entry = tk.Entry(
    window,
    width=20,
    font=("Arial", 12)
)
entry.insert(0, "This is entry Widget")
entry.pack(pady=25)


def open_form():
    form = tk.Toplevel(window)
    form.title("tk #2")
    form.geometry("340x210")
    form.resizable(False, False)

    fields = [
        ("Last Name", "Klein"),
        ("First Name", "Bernd"),
        ("Job", "Trainer"),
        ("Country", "Germany")
    ]

    entries = {}

    for row, (field_name, default_value) in enumerate(fields):
        label = tk.Label(form, text=field_name, anchor="w")
        label.grid(
            row=row, column=0,
            padx=(10, 15), pady=5, sticky="w"
        )

        entry = tk.Entry(form, width=20)
        entry.insert(0, default_value)
        entry.grid(
            row=row, column=1,
            padx=(0, 10), pady=5, sticky="ew"
        )

        entries[field_name] = entry

    def show_values():
        for name, entry in entries.items():
            print(f"{name}: {entry.get()}")

    show_button = tk.Button(
        form, text="Show", width=8,
        command=show_values
    )
    show_button.grid(
        row=4, column=0,
        padx=10, pady=8, sticky="w"
    )

    quit_button = tk.Button(
        form, text="Quit", width=8,
        command=form.destroy
    )
    quit_button.grid(
        row=4, column=1,
        padx=0, pady=8, sticky="w"
    )


window.mainloop()
