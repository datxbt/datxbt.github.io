import tkinter as tk
window = tk.Tk()
window.title("Hello Python")
window.geometry("300x200")

label = tk.Label(master=window, text="Welcome to Harry Travels", font=20)
label.grid(padx=60, pady=20)

tk.Label(window, text="Username:", font=("Arial", 12)).grid(
    row=1, column=0, padx=10, pady=5, sticky="w"
)

username = tk.Entry(window, width=3, font=("Arial", 12))
username.insert(0, "Robo")
username.grid(row=1, column=1, padx=5, pady=5)

tk.Label(window, text="Password:", font=("Arial", 12)).grid(
    row=2, column=0, padx=10, pady=5, sticky="w"
)

password = tk.Entry(window, width=3, font=("Arial", 12), show="*")
password.grid(row=2, column=1, padx=5, pady=5)

window.mainloop()