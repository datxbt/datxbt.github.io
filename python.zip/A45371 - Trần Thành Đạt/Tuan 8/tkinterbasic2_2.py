
import tkinter as tk
from tkinter import messagebox

window = tk.Tk()
window.title("Sign In")
window.geometry("370x225")
window.resizable(False, False)

# Email label and input
tk.Label(window, text="Email Address:").pack(
    anchor="w", padx=14, pady=(15, 3)
)

email = tk.Entry(window, font=("Arial", 11))
email.pack(fill="x", padx=14)

# Password label and input
tk.Label(window, text="Password:").pack(
    anchor="w", padx=14, pady=(5, 3)
)

password = tk.Entry(window, show="*", font=("Arial", 11))
password.pack(fill="x", padx=14)

# Login button
def login():
    messagebox.showinfo(
        "Sign In",
        f"Email: {email.get()}\nPassword entered."
    )

tk.Button(
    window,
    text="Login",
    command=login
).pack(fill="x", padx=14, pady=14)

window.mainloop()
