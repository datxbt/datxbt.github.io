# DAP AN MAU - CAU 1: Tinh tien dien (2 diem)
# Chi mo file nay SAU KHI da lam xong bai.

from tkinter import *
from tkinter import messagebox

BAC = [(50, 1800), (50, 1900), (100, 2200), (None, 2800)]   # (so kWh cua bac, don gia); None = phan con lai
VAT = 0.10


def tinh_tien(kwh):
    """Tinh tien dien bac thang (chua VAT)."""
    tien = 0
    con_lai = kwh
    for so_kwh, gia in BAC:
        if con_lai <= 0:
            break
        dung = con_lai if so_kwh is None else min(con_lai, so_kwh)
        tien += dung * gia
        con_lai -= dung
    return tien


def xu_ly(event=None):          # event=None de dung chung cho Button (command) va bind (<Return>)
    try:
        kwh = int(txtKwh.get())
        if kwh < 0:
            raise ValueError
    except ValueError:
        messagebox.showerror("Lỗi", "Số kWh phải là số nguyên không âm!")
        xoa()
        return
    tien = tinh_tien(kwh)
    thue = tien * VAT
    lblTien.config(text=f"{tien:,.0f} đ")
    lblVat.config(text=f"{thue:,.0f} đ")
    lblTong.config(text=f"{tien + thue:,.0f} đ")


def xoa():
    txtKwh.delete(0, END)
    for lbl in (lblTien, lblVat, lblTong):
        lbl.config(text="")
    txtKwh.focus()


ws = Tk()
ws.title("Tính tiền điện")
ws.geometry("380x230")
ws.resizable(False, False)

Label(ws, text="TÍNH TIỀN ĐIỆN", font=("Arial", 16, "bold")).grid(row=0, column=0, columnspan=3, pady=10)

Label(ws, text="Số kWh:").grid(row=1, column=0, sticky=W, padx=10)
txtKwh = Entry(ws, width=20)
txtKwh.grid(row=1, column=1, columnspan=2, sticky=W)

Label(ws, text="Tiền điện:").grid(row=2, column=0, sticky=W, padx=10, pady=3)
lblTien = Label(ws, text="", fg="blue")
lblTien.grid(row=2, column=1, sticky=W)

Label(ws, text="Thuế VAT 10%:").grid(row=3, column=0, sticky=W, padx=10, pady=3)
lblVat = Label(ws, text="", fg="blue")
lblVat.grid(row=3, column=1, sticky=W)

Label(ws, text="Tổng phải trả:").grid(row=4, column=0, sticky=W, padx=10, pady=3)
lblTong = Label(ws, text="", fg="red", font=("Arial", 11, "bold"))
lblTong.grid(row=4, column=1, sticky=W)

Button(ws, text="Tính", width=10, command=xu_ly).grid(row=5, column=1, pady=10, sticky=W)
Button(ws, text="Xóa", width=10, command=xoa).grid(row=5, column=2, pady=10, sticky=W)

ws.bind("<Return>", xu_ly)
txtKwh.focus()
ws.mainloop()
