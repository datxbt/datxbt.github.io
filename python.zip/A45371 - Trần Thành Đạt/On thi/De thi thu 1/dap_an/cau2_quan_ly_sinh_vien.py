# DAP AN MAU - CAU 2: Quan ly sinh vien (8 diem)
# Chi mo file nay SAU KHI da lam xong bai.
# Chay trong thu muc co file khoa.txt.

import re
import sqlite3
from tkinter import *
from tkinter import ttk, messagebox

# ================= c) CSDL =================
con = sqlite3.connect("quanlysinhvien.db")
cur = con.cursor()
cur.execute("""CREATE TABLE IF NOT EXISTS sinhvien(
    masv TEXT PRIMARY KEY,
    hoten TEXT NOT NULL,
    email TEXT,
    sdt TEXT,
    gioitinh TEXT,
    khoa TEXT,
    sothich TEXT)""")
con.commit()

# ================= a) Giao dien =================
ws = Tk()
ws.title("Quản lý sinh viên")
ws.geometry("860x560")

# Doc khoa.txt vao list
try:
    with open("khoa.txt", encoding="utf-8") as f:
        ds_khoa = [d.strip() for d in f if d.strip()]
except FileNotFoundError:
    ds_khoa = []
    messagebox.showwarning("Thiếu file", "Không tìm thấy khoa.txt")

gioitinh_var = StringVar(value="")          # ban dau chua chon
SO_THICH = ["Thể thao", "Âm nhạc", "Đọc sách"]
sothich_vars = [IntVar() for _ in SO_THICH]  # moi Checkbutton mot bien rieng

frm = LabelFrame(ws, text="Thông tin sinh viên", padx=10, pady=8)
frm.pack(fill=X, padx=10, pady=8)

Label(frm, text="Mã SV:").grid(row=0, column=0, sticky=W, pady=3)
txtMa = Entry(frm, width=25)
txtMa.grid(row=0, column=1, sticky=W)

Label(frm, text="Họ tên:").grid(row=1, column=0, sticky=W, pady=3)
txtTen = Entry(frm, width=25)
txtTen.grid(row=1, column=1, sticky=W)

Label(frm, text="Email:").grid(row=2, column=0, sticky=W, pady=3)
txtEmail = Entry(frm, width=25)
txtEmail.grid(row=2, column=1, sticky=W)

Label(frm, text="Số điện thoại:").grid(row=3, column=0, sticky=W, pady=3)
txtSdt = Entry(frm, width=25)
txtSdt.grid(row=3, column=1, sticky=W)

Label(frm, text="Giới tính:").grid(row=0, column=2, sticky=W, padx=(30, 5))
frmGT = Frame(frm)
frmGT.grid(row=0, column=3, sticky=W)
Radiobutton(frmGT, text="Nam", variable=gioitinh_var, value="Nam").pack(side=LEFT)
Radiobutton(frmGT, text="Nữ", variable=gioitinh_var, value="Nữ").pack(side=LEFT)

Label(frm, text="Khoa:").grid(row=1, column=2, sticky=W, padx=(30, 5))
cboKhoa = ttk.Combobox(frm, values=ds_khoa, state="readonly", width=28)
cboKhoa.grid(row=1, column=3, sticky=W)

Label(frm, text="Sở thích:").grid(row=2, column=2, sticky=W, padx=(30, 5))
frmST = Frame(frm)
frmST.grid(row=2, column=3, sticky=W)
for ten, var in zip(SO_THICH, sothich_vars):
    Checkbutton(frmST, text=ten, variable=var).pack(side=LEFT)

# ================= b) Validate =================
def validate():
    if not re.match(r"^A\d{5}$", txtMa.get().strip()):
        messagebox.showerror("Lỗi", "Mã SV phải có dạng A + 5 chữ số (ví dụ A45371)!")
        return False
    if txtTen.get().strip() == "":
        messagebox.showerror("Lỗi", "Bạn cần nhập họ tên!")
        return False
    if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", txtEmail.get().strip()):
        messagebox.showerror("Lỗi", "Email không hợp lệ!")
        return False
    sdt = txtSdt.get().strip()
    if not (sdt.isdigit() and len(sdt) == 10 and sdt.startswith("0")):
        messagebox.showerror("Lỗi", "Số điện thoại phải gồm 10 chữ số và bắt đầu bằng 0!")
        return False
    if gioitinh_var.get() == "":
        messagebox.showerror("Lỗi", "Bạn cần chọn giới tính!")
        return False
    if cboKhoa.get() == "":
        messagebox.showerror("Lỗi", "Bạn cần chọn khoa!")
        return False
    return True


def lay_form():
    sothich = ", ".join(ten for ten, var in zip(SO_THICH, sothich_vars) if var.get() == 1)
    return (txtMa.get().strip(), txtTen.get().strip(), txtEmail.get().strip(),
            txtSdt.get().strip(), gioitinh_var.get(), cboKhoa.get(), sothich)


# ================= c), d) Xu ly =================
def load_data():
    for item in tree.get_children():
        tree.delete(item)
    cur.execute("SELECT masv, hoten, email, sdt, gioitinh, khoa, sothich FROM sinhvien ORDER BY masv")
    for row in cur.fetchall():
        tree.insert("", END, iid=row[0], values=row)   # iid = masv de tim lai dong de dang


def lam_moi():
    txtMa.config(state=NORMAL)
    for e in (txtMa, txtTen, txtEmail, txtSdt):
        e.delete(0, END)
    gioitinh_var.set("")
    cboKhoa.set("")
    for var in sothich_vars:
        var.set(0)
    tree.selection_remove(tree.selection())
    txtMa.focus()


def them():
    if not validate():
        return
    try:
        cur.execute("INSERT INTO sinhvien VALUES (?, ?, ?, ?, ?, ?, ?)", lay_form())
        con.commit()
    except sqlite3.IntegrityError:
        messagebox.showerror("Lỗi", "Mã sinh viên đã tồn tại!")
        return
    messagebox.showinfo("Thông báo", "Đã thêm sinh viên.")
    load_data()
    lam_moi()


def chon_dong(event=None):
    sel = tree.selection()
    if not sel:
        return
    masv = sel[0]
    # Lay lai tu CSDL thay vi tu Treeview: Treeview bien "0912..." thanh so 912... (mat so 0)
    cur.execute("SELECT * FROM sinhvien WHERE masv=?", (masv,))
    row = cur.fetchone()
    if row is None:
        return
    lam_moi_giu_chon()
    ma, ten, email, sdt, gt, khoa, sothich = row
    txtMa.insert(0, ma)
    txtMa.config(state="readonly")       # khong cho sua ma SV
    txtTen.insert(0, ten)
    txtEmail.insert(0, email)
    txtSdt.insert(0, sdt)
    gioitinh_var.set(gt)
    cboKhoa.set(khoa)
    ds = sothich.split(", ") if sothich else []
    for ten_st, var in zip(SO_THICH, sothich_vars):
        var.set(1 if ten_st in ds else 0)


def lam_moi_giu_chon():
    txtMa.config(state=NORMAL)
    for e in (txtMa, txtTen, txtEmail, txtSdt):
        e.delete(0, END)
    gioitinh_var.set("")
    cboKhoa.set("")
    for var in sothich_vars:
        var.set(0)


def sua():
    if not tree.selection():
        messagebox.showwarning("Chú ý", "Hãy chọn sinh viên cần sửa.")
        return
    if not validate():
        return
    ma, ten, email, sdt, gt, khoa, sothich = lay_form()
    cur.execute("UPDATE sinhvien SET hoten=?, email=?, sdt=?, gioitinh=?, khoa=?, sothich=? WHERE masv=?",
                (ten, email, sdt, gt, khoa, sothich, ma))
    con.commit()
    messagebox.showinfo("Thông báo", "Đã cập nhật.")
    load_data()
    lam_moi()


def xoa():
    sel = tree.selection()
    if not sel:
        messagebox.showwarning("Chú ý", "Hãy chọn sinh viên cần xóa.")
        return
    if messagebox.askyesno("Xác nhận", f"Xóa sinh viên {sel[0]}?"):
        cur.execute("DELETE FROM sinhvien WHERE masv=?", (sel[0],))
        con.commit()
        load_data()
        lam_moi()


def thoat():
    if messagebox.askyesno("Thoát", "Bạn có thực sự muốn thoát?"):
        con.close()
        ws.destroy()


frmNut = Frame(ws)
frmNut.pack(pady=4)
for text, cmd in (("Thêm", them), ("Sửa", sua), ("Xóa", xoa), ("Làm mới", lam_moi)):
    Button(frmNut, text=text, width=10, command=cmd).pack(side=LEFT, padx=4)

# Treeview + Scrollbar
frmTree = Frame(ws)
frmTree.pack(fill=BOTH, expand=True, padx=10, pady=8)
cot = ("masv", "hoten", "email", "sdt", "gioitinh", "khoa", "sothich")
tieu_de = ("Mã SV", "Họ tên", "Email", "SĐT", "Giới tính", "Khoa", "Sở thích")
do_rong = (70, 150, 170, 95, 65, 160, 150)
tree = ttk.Treeview(frmTree, columns=cot, show="headings")
for c, t, w in zip(cot, tieu_de, do_rong):
    tree.heading(c, text=t)
    tree.column(c, width=w, anchor=W)
sb = ttk.Scrollbar(frmTree, orient=VERTICAL, command=tree.yview)
tree.configure(yscrollcommand=sb.set)
tree.pack(side=LEFT, fill=BOTH, expand=True)
sb.pack(side=RIGHT, fill=Y)
tree.bind("<<TreeviewSelect>>", chon_dong)

# ================= e) Menu + popup =================
menubar = Menu(ws)
filemenu = Menu(menubar, tearoff=0)
filemenu.add_command(label="Làm mới", command=lam_moi)
filemenu.add_separator()
filemenu.add_command(label="Thoát", command=thoat)
menubar.add_cascade(label="File", menu=filemenu)
ws.config(menu=menubar)

popup = Menu(ws, tearoff=0)
popup.add_command(label="Xóa sinh viên này", command=xoa)


def hien_popup(event):
    dong = tree.identify_row(event.y)
    if dong:
        tree.selection_set(dong)
        try:
            popup.tk_popup(event.x_root, event.y_root)
        finally:
            popup.grab_release()


tree.bind("<Button-3>", hien_popup)
ws.protocol("WM_DELETE_WINDOW", thoat)

load_data()
ws.mainloop()
