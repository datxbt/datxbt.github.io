# BƯỚC 2: Treeview (chưa có CSDL) - Treeview = cái BẢNG hiển thị nhiều dòng, nhiều cột
# Chạy thử: bấm vào 1 dòng -> xem cửa sổ terminal in ra gì. Bấm nút Xóa dòng chọn.

from tkinter import *
from tkinter import ttk

ws = Tk()
ws.title("Học Treeview")
ws.geometry("500x300")

# 1) Tạo Treeview: columns = tên "mã" của các cột; show="headings" để ẩn cột #0 thừa bên trái
cot = ("masv", "hoten", "sdt")
tree = ttk.Treeview(ws, columns=cot, show="headings", height=8)

# 2) Đặt tiêu đề + độ rộng cho từng cột
tree.heading("masv", text="Mã SV")
tree.heading("hoten", text="Họ tên")
tree.heading("sdt", text="SĐT")
tree.column("masv", width=80)
tree.column("hoten", width=200)
tree.column("sdt", width=120)

# 3) Thanh cuộn dọc: 2 dòng "nối" tree và scrollbar với nhau
sb = ttk.Scrollbar(ws, orient=VERTICAL, command=tree.yview)
tree.configure(yscrollcommand=sb.set)

tree.grid(row=0, column=0, padx=10, pady=10)
sb.grid(row=0, column=1, sticky="ns", pady=10)   # sticky ns = kéo dài trên-dưới

# 4) Thêm dòng: tree.insert("", END, values=(...))
du_lieu = [("A00001", "Nguyễn Văn An", "0912345678"),
           ("A00002", "Trần Thị Bình", "0987654321"),
           ("A00003", "Lê Văn Cường", "0901112223")]
for row in du_lieu:
    tree.insert("", END, values=row)


# 5) Bắt sự kiện chọn dòng
def chon_dong(event):
    sel = tree.selection()          # tuple các id dòng đang chọn, vd ('I001',)
    if not sel:
        return
    values = tree.item(sel[0])["values"]   # lấy list giá trị của dòng đó
    print("Bạn chọn:", values)
    # Để ý: '0912345678' in ra thành 912345678 (MẤT SỐ 0) -> Treeview tự đổi sang số.
    # Vì vậy bài thi nên lấy mã SV rồi SELECT lại từ CSDL (xem bước 4).


tree.bind("<<TreeviewSelect>>", chon_dong)


# 6) Xóa dòng đang chọn / xóa hết
def xoa_dong_chon():
    for id_dong in tree.selection():
        tree.delete(id_dong)


def xoa_het():
    for id_dong in tree.get_children():   # get_children() = tất cả các dòng
        tree.delete(id_dong)


Button(ws, text="Xóa dòng chọn", command=xoa_dong_chon).grid(row=1, column=0, sticky="w", padx=10)
Button(ws, text="Xóa hết", command=xoa_het).grid(row=1, column=0)

ws.mainloop()

# TÓM TẮT cần thuộc:
#   tree = ttk.Treeview(ws, columns=cot, show="headings")
#   tree.heading(c, text=...)            tree.insert("", END, values=row)
#   tree.get_children() + tree.delete()  -> xóa hết
#   tree.selection()[0] + tree.item(id)["values"]  -> dòng đang chọn
#   tree.bind("<<TreeviewSelect>>", ham)
