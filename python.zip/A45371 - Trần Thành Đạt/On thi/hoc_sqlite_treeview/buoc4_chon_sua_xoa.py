# BƯỚC 4: thêm CHỌN DÒNG -> hiện lên form, SỬA, XÓA  (= bước 3 + 3 hàm mới)
# Đây là khung CRUD hoàn chỉnh. Học thuộc file này là làm được phần c), d) của đề.

import sqlite3
from tkinter import *
from tkinter import ttk, messagebox

con = sqlite3.connect("hoc.db")
cur = con.cursor()
cur.execute("CREATE TABLE IF NOT EXISTS sinhvien(masv TEXT PRIMARY KEY, hoten TEXT, sdt TEXT)")
con.commit()

ws = Tk()
ws.title("Bước 4: Chọn - Sửa - Xóa")

Label(ws, text="Mã SV:").grid(row=0, column=0, sticky=W, padx=5)
txtMa = Entry(ws)
txtMa.grid(row=0, column=1)
Label(ws, text="Họ tên:").grid(row=1, column=0, sticky=W, padx=5)
txtTen = Entry(ws)
txtTen.grid(row=1, column=1)
Label(ws, text="SĐT:").grid(row=2, column=0, sticky=W, padx=5)
txtSdt = Entry(ws)
txtSdt.grid(row=2, column=1)

frmNut = Frame(ws)
frmNut.grid(row=3, column=0, columnspan=3, pady=5)

cot = ("masv", "hoten", "sdt")
tree = ttk.Treeview(ws, columns=cot, show="headings", height=8)
for c, t in zip(cot, ("Mã SV", "Họ tên", "SĐT")):
    tree.heading(c, text=t)
tree.grid(row=4, column=0, columnspan=3, padx=10, pady=10)


def load_data():
    for i in tree.get_children():
        tree.delete(i)
    cur.execute("SELECT * FROM sinhvien")
    for row in cur.fetchall():
        tree.insert("", END, iid=row[0], values=row)   # MỚI: iid = mã SV -> id dòng chính là mã


def lam_moi():
    txtMa.config(state=NORMAL)
    for e in (txtMa, txtTen, txtSdt):
        e.delete(0, END)


def them():
    try:
        cur.execute("INSERT INTO sinhvien VALUES (?, ?, ?)",
                    (txtMa.get().strip(), txtTen.get().strip(), txtSdt.get().strip()))
        con.commit()
    except sqlite3.IntegrityError:
        messagebox.showerror("Lỗi", "Mã sinh viên đã tồn tại!")
        return
    load_data()
    lam_moi()


# MỚI 1: chọn dòng -> đổ dữ liệu lên form
def chon_dong(event):
    sel = tree.selection()
    if not sel:
        return
    masv = sel[0]                       # nhờ iid=masv nên id dòng = mã SV
    cur.execute("SELECT * FROM sinhvien WHERE masv=?", (masv,))   # đọc lại từ CSDL (giữ số 0 của SĐT)
    ma, ten, sdt = cur.fetchone()
    lam_moi()
    txtMa.insert(0, ma)
    txtMa.config(state="readonly")      # không cho sửa mã
    txtTen.insert(0, ten)
    txtSdt.insert(0, sdt)


# MỚI 2: sửa theo mã
def sua():
    if not tree.selection():
        messagebox.showwarning("Chú ý", "Chọn một dòng trước!")
        return
    cur.execute("UPDATE sinhvien SET hoten=?, sdt=? WHERE masv=?",
                (txtTen.get().strip(), txtSdt.get().strip(), txtMa.get()))
    con.commit()
    load_data()
    lam_moi()


# MỚI 3: xóa có hỏi xác nhận
def xoa():
    sel = tree.selection()
    if not sel:
        messagebox.showwarning("Chú ý", "Chọn một dòng trước!")
        return
    if messagebox.askyesno("Xác nhận", f"Xóa sinh viên {sel[0]}?"):   # askyesno trả về True/False
        cur.execute("DELETE FROM sinhvien WHERE masv=?", (sel[0],))
        con.commit()
        load_data()
        lam_moi()


tree.bind("<<TreeviewSelect>>", chon_dong)
for text, cmd in (("Thêm", them), ("Sửa", sua), ("Xóa", xoa), ("Làm mới", lam_moi)):
    Button(frmNut, text=text, width=9, command=cmd).pack(side=LEFT, padx=3)
    # pack trong frmNut là OK: frmNut là khung riêng, không trộn với grid của ws

load_data()
ws.mainloop()
con.close()

# SƠ ĐỒ NHỚ:
#   Thêm / Sửa / Xóa  --> cur.execute(SQL, tuple) --> con.commit() --> load_data() --> lam_moi()
#   Chọn dòng         --> tree.selection()[0] = mã --> SELECT ... WHERE masv=? --> insert lên form
