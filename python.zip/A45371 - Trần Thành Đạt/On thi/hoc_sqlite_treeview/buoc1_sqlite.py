# BƯỚC 1: SQLite (chưa có giao diện) - chạy rồi đọc kết quả in ra màn hình
# SQLite = một CSDL nằm gọn trong 1 file .db, Python có sẵn thư viện sqlite3, không cần cài gì.

import sqlite3

# 1) Kết nối: nếu file chưa có thì tự tạo
con = sqlite3.connect("hoc.db")
cur = con.cursor()          # cursor = "cây bút" để chạy câu lệnh SQL

# 2) Tạo bảng. IF NOT EXISTS => chạy lại lần 2 không bị lỗi "table already exists"
cur.execute("""CREATE TABLE IF NOT EXISTS sinhvien(
    masv  TEXT PRIMARY KEY,   -- khóa chính: không được trùng
    hoten TEXT,
    sdt   TEXT                -- SĐT để TEXT, không để INTEGER (giữ số 0 đầu)
)""")

# 3) THÊM (INSERT). Dùng dấu ? rồi truyền tuple giá trị -> an toàn, không lo dấu nháy
try:
    cur.execute("INSERT INTO sinhvien VALUES (?, ?, ?)", ("A00001", "Nguyễn Văn An", "0912345678"))
    cur.execute("INSERT INTO sinhvien VALUES (?, ?, ?)", ("A00002", "Trần Thị Bình", "0987654321"))
    con.commit()            # QUAN TRỌNG: không commit thì tắt chương trình là mất dữ liệu
except sqlite3.IntegrityError:
    print("Mã SV đã tồn tại! (lần chạy thứ 2 sẽ thấy dòng này - đó là PRIMARY KEY hoạt động)")

# 4) ĐỌC (SELECT). fetchall() trả về list các tuple
cur.execute("SELECT * FROM sinhvien")
rows = cur.fetchall()
print("Tất cả:", rows)      # [('A00001', 'Nguyễn Văn An', '0912345678'), (...)]
for row in rows:
    print("  ", row[0], "|", row[1], "|", row[2])

# Lấy 1 dòng theo mã. Chú ý (masv,) có dấu phẩy => tuple 1 phần tử
cur.execute("SELECT * FROM sinhvien WHERE masv=?", ("A00001",))
print("Một dòng:", cur.fetchone())

# 5) SỬA (UPDATE)
cur.execute("UPDATE sinhvien SET hoten=? WHERE masv=?", ("Nguyễn Văn An (đã sửa)", "A00001"))
con.commit()

# 6) XÓA (DELETE)
cur.execute("DELETE FROM sinhvien WHERE masv=?", ("A00002",))
con.commit()

cur.execute("SELECT * FROM sinhvien")
print("Sau khi sửa và xóa:", cur.fetchall())

con.close()

# TÓM TẮT 4 câu cần thuộc:
#   INSERT INTO bang VALUES (?, ?, ?)
#   SELECT * FROM bang                 /  SELECT * FROM bang WHERE ma=?
#   UPDATE bang SET cot1=?, cot2=? WHERE ma=?
#   DELETE FROM bang WHERE ma=?
# Sau INSERT/UPDATE/DELETE luôn con.commit()
