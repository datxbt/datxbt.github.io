# BƯỚC 3: GHÉP SQLite + Treeview -> nút THÊM
# Ý tưởng duy nhất cần nhớ:  CSDL là nơi LƯU, Treeview chỉ để HIỂN THỊ.
#   Thêm vào CSDL -> commit -> gọi load_data() để vẽ lại Treeview từ CSDL.
# Phần này đã đủ ăn ~1,5 điểm phần c) của đề.

import sqlite3
from tkinter import *
from tkinter import ttk, messagebox

# --- CSDL ---
con = sqlite3.connect("hoc.db")
cur = con.cursor()
cur.execute("CREATE TABLE IF NOT EXISTS sinhvien(masv TEXT PRIMARY KEY, hoten TEXT, sdt TEXT)")
con.commit()

ws = Tk()
ws.title("Bước 3: Thêm")

# --- Form ---
Label(ws, text="Mã SV:").grid(row=0, column=0, sticky=W, padx=5)
txtMa = Entry(ws)
txtMa.grid(row=0, column=1)
Label(ws, text="Họ tên:").grid(row=1, column=0, sticky=W, padx=5)
txtTen = Entry(ws)
txtTen.grid(row=1, column=1)
Label(ws, text="SĐT:").grid(row=2, column=0, sticky=W, padx=5)
txtSdt = Entry(ws)
txtSdt.grid(row=2, column=1)

# --- Treeview ---
cot = ("masv", "hoten", "sdt")
tree = ttk.Treeview(ws, columns=cot, show="headings", height=8)
for c, t in zip(cot, ("Mã SV", "Họ tên", "SĐT")):
    tree.heading(c, text=t)
tree.grid(row=4, column=0, columnspan=3, padx=10, pady=10)


# --- Hàm 1: nạp lại toàn bộ Treeview từ CSDL (dùng đi dùng lại) ---
def load_data():
    for i in tree.get_children():       # B1: xóa hết dòng cũ trên Treeview
        tree.delete(i)
    cur.execute("SELECT * FROM sinhvien")   # B2: đọc CSDL
    for row in cur.fetchall():          # B3: đổ từng dòng vào Treeview
        tree.insert("", END, values=row)


# --- Hàm 2: thêm ---
def them():
    ma, ten, sdt = txtMa.get().strip(), txtTen.get().strip(), txtSdt.get().strip()
    if ma == "" or ten == "":
        messagebox.showerror("Lỗi", "Nhập mã và họ tên!")
        return
    try:
        cur.execute("INSERT INTO sinhvien VALUES (?, ?, ?)", (ma, ten, sdt))
        con.commit()
    except sqlite3.IntegrityError:          # trùng PRIMARY KEY
        messagebox.showerror("Lỗi", "Mã sinh viên đã tồn tại!")
        return
    load_data()                             # vẽ lại bảng
    for e in (txtMa, txtTen, txtSdt):       # xóa trắng form
        e.delete(0, END)


Button(ws, text="Thêm", width=10, command=them).grid(row=3, column=1, pady=5)

load_data()      # nạp ngay khi mở chương trình
ws.mainloop()
con.close()
