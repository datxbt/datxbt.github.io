# KHUNG ON THI TKINTER + SQLITE
# Luyen go lai file nay tu dau cho den khi lam duoc trong 15-20 phut.
# Gom du cac phan hay ra thi: form, Radiobutton, Combobox doc tu file,
# validate, them/sua/xoa SQLite, Treeview + Scrollbar, chon dong, menu, popup menu.

import re
import sqlite3
from tkinter import *
from tkinter import ttk, messagebox

# ---------------- 1. CSDL ----------------
con = sqlite3.connect("quanlynhanvien_onthi.db")
cur = con.cursor()
cur.execute("""CREATE TABLE IF NOT EXISTS nhanvien(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ten TEXT NOT NULL,
    email TEXT,
    gioitinh TEXT,
    quocgia TEXT)""")
con.commit()

# ---------------- 2. Cua so + bien ----------------
ws = Tk()
ws.title("Quản lý nhân viên")
ws.geometry("720x500")

gioitinh_var = StringVar(value="Nam")
selected_id = None   # id cua dong dang chon tren Treeview

# Doc file text de nap vao Combobox
try:
    with open("countries.txt", encoding="utf-8") as f:
        countries = [dong.strip() for dong in f if dong.strip()]
except FileNotFoundError:
    countries = ["Viet Nam", "Japan", "Korea", "USA"]

# ---------------- 3. Form nhap lieu (grid trong LabelFrame) ----------------
frm = LabelFrame(ws, text="Thông tin nhân viên", padx=10, pady=10)
frm.pack(fill=X, padx=10, pady=10)

Label(frm, text="Họ tên:").grid(row=0, column=0, sticky=W, pady=4)
txtTen = Entry(frm, width=35)
txtTen.grid(row=0, column=1, columnspan=2, sticky=W)

Label(frm, text="Email:").grid(row=1, column=0, sticky=W, pady=4)
txtEmail = Entry(frm, width=35)
txtEmail.grid(row=1, column=1, columnspan=2, sticky=W)

Label(frm, text="Giới tính:").grid(row=2, column=0, sticky=W, pady=4)
Radiobutton(frm, text="Nam", variable=gioitinh_var, value="Nam").grid(row=2, column=1, sticky=W)
Radiobutton(frm, text="Nữ", variable=gioitinh_var, value="Nữ").grid(row=2, column=2, sticky=W)

Label(frm, text="Quốc gia:").grid(row=3, column=0, sticky=W, pady=4)
cboQuocGia = ttk.Combobox(frm, values=countries, state="readonly", width=32)
cboQuocGia.grid(row=3, column=1, columnspan=2, sticky=W)


# ---------------- 4. Cac ham xu ly ----------------
def load_data():
    for item in tree.get_children():      # xoa het dong cu truoc khi nap lai
        tree.delete(item)
    cur.execute("SELECT id, ten, email, gioitinh, quocgia FROM nhanvien")
    for row in cur.fetchall():
        tree.insert("", END, values=row)


def clear_form():
    global selected_id
    selected_id = None
    txtTen.delete(0, END)
    txtEmail.delete(0, END)
    gioitinh_var.set("Nam")
    cboQuocGia.set("")
    txtTen.focus()


def validate():
    ten = txtTen.get().strip()
    email = txtEmail.get().strip()
    if ten == "":
        messagebox.showerror("Lỗi", "Bạn cần nhập họ tên!")
        return False
    if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email):
        messagebox.showerror("Lỗi", "Email không hợp lệ!")
        return False
    if cboQuocGia.get() == "":
        messagebox.showerror("Lỗi", "Bạn cần chọn quốc gia!")
        return False
    return True


def them():
    if not validate():
        return
    try:
        cur.execute("INSERT INTO nhanvien(ten, email, gioitinh, quocgia) VALUES (?, ?, ?, ?)",
                    (txtTen.get().strip(), txtEmail.get().strip(), gioitinh_var.get(), cboQuocGia.get()))
        con.commit()
    except sqlite3.Error as e:
        messagebox.showerror("Lỗi CSDL", str(e))
        return
    messagebox.showinfo("Thông báo", "Đã thêm nhân viên.")
    load_data()
    clear_form()


def sua():
    if selected_id is None:
        messagebox.showwarning("Chú ý", "Hãy chọn một dòng để sửa.")
        return
    if not validate():
        return
    cur.execute("UPDATE nhanvien SET ten=?, email=?, gioitinh=?, quocgia=? WHERE id=?",
                (txtTen.get().strip(), txtEmail.get().strip(), gioitinh_var.get(), cboQuocGia.get(), selected_id))
    con.commit()
    load_data()
    clear_form()


def xoa():
    if selected_id is None:
        messagebox.showwarning("Chú ý", "Hãy chọn một dòng để xóa.")
        return
    if messagebox.askyesno("Xác nhận", "Bạn có chắc muốn xóa?"):
        cur.execute("DELETE FROM nhanvien WHERE id=?", (selected_id,))   # (x,) la tuple
        con.commit()
        load_data()
        clear_form()


def chon_dong(event):
    global selected_id
    sel = tree.selection()
    if not sel:
        return
    id_, ten, email, gt, qg = tree.item(sel[0])["values"]
    clear_form()
    selected_id = id_
    txtTen.insert(0, ten)
    txtEmail.insert(0, email)
    gioitinh_var.set(gt)
    cboQuocGia.set(qg)


def thoat():
    if messagebox.askyesno("Thoát", "Bạn có thực sự muốn thoát?"):
        con.close()
        ws.destroy()


# ---------------- 5. Nut bam ----------------
frmNut = Frame(ws)
frmNut.pack(pady=5)
Button(frmNut, text="Thêm", width=10, command=them).pack(side=LEFT, padx=4)
Button(frmNut, text="Sửa", width=10, command=sua).pack(side=LEFT, padx=4)
Button(frmNut, text="Xóa", width=10, command=xoa).pack(side=LEFT, padx=4)
Button(frmNut, text="Làm mới", width=10, command=clear_form).pack(side=LEFT, padx=4)

# ---------------- 6. Treeview + Scrollbar ----------------
frmTree = Frame(ws)
frmTree.pack(fill=BOTH, expand=True, padx=10, pady=10)
cot = ("id", "ten", "email", "gioitinh", "quocgia")
tree = ttk.Treeview(frmTree, columns=cot, show="headings", height=8)
for c, tieude, rong in zip(cot, ("ID", "Họ tên", "Email", "Giới tính", "Quốc gia"), (40, 160, 200, 80, 120)):
    tree.heading(c, text=tieude)
    tree.column(c, width=rong, anchor=W)
sb = ttk.Scrollbar(frmTree, orient=VERTICAL, command=tree.yview)
tree.configure(yscrollcommand=sb.set)
tree.pack(side=LEFT, fill=BOTH, expand=True)
sb.pack(side=RIGHT, fill=Y)
tree.bind("<<TreeviewSelect>>", chon_dong)

# ---------------- 7. Menu + popup menu chuot phai ----------------
menubar = Menu(ws)
filemenu = Menu(menubar, tearoff=0)
filemenu.add_command(label="Làm mới form", command=clear_form)
filemenu.add_separator()
filemenu.add_command(label="Thoát", command=thoat)
menubar.add_cascade(label="File", menu=filemenu)
ws.config(menu=menubar)

popup = Menu(ws, tearoff=0)
popup.add_command(label="Sửa dòng này", command=sua)
popup.add_command(label="Xóa dòng này", command=xoa)


def hien_popup(event):
    dong = tree.identify_row(event.y)   # chon dong duoi con tro truoc khi hien menu
    if dong:
        tree.selection_set(dong)
    try:
        popup.tk_popup(event.x_root, event.y_root)
    finally:
        popup.grab_release()


tree.bind("<Button-3>", hien_popup)
ws.protocol("WM_DELETE_WINDOW", thoat)   # bam dau X cung hoi xac nhan

load_data()
ws.mainloop()
