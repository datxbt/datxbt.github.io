# Bai 1
print("NHAP DAY LON CUA HINH THANG:")
daylon = float(input())

print("NHAP DAY NHO CUA HINH THANG:")
daynho = float(input())

print("NHAP CANH BEN 1 CUA HINH THANG:")
canhben1 = float(input())

print("NHAP CANH BEN 2 CUA HINH THANG:")
canhben2 = float(input())

print("NHAP CHIEU CAO CUA HINH THANG:")
caothang = float(input())

chuvihinhthang = daylon + daynho + canhben1 + canhben2
dientichhinhthang = ((daylon + daynho) * caothang) / 2

print("CHU VI HINH THANG:", chuvihinhthang)
print("DIEN TICH HINH THANG:", dientichhinhthang)

#Bai 2
print("NHAP SO DOLLAR:")
DOLLAR = int(input())
VND = DOLLAR * 23000
print("VND TUONG UNG VOI",DOLLAR,"DOLLAR", "LA:",VND)
