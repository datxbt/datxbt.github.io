hotten = input("NHAP HO TEN: ")
diemthi = int(input("NHAP DIEM THI: "))

# Tính điểm thưởng
if 21 <= diemthi <= 25:
    diemthuong = 5
elif 16 <= diemthi <= 20:
    diemthuong = 3
elif 10 <= diemthi <= 15:
    diemthuong = 1
else:
    diemthuong = 0

# Tổng điểm sau khi cộng thưởng
tongdiem = diemthi + diemthuong

# Xếp loại
if 0 <= tongdiem < 10:
    xeploai = "D"
elif 10 <= tongdiem < 15:
    xeploai = "C"
elif 15 <= tongdiem < 20:
    xeploai = "B"
elif 20 <= tongdiem <= 30:
    xeploai = "A"
else:
    xeploai = "Khong hop le"

# In kết quả
print("Ho ten:", hotten)
print("Diem thi:", diemthi)
print("Diem thuong:", diemthuong)
print("Tong diem:", tongdiem)
print("Xep loai:", xeploai)
