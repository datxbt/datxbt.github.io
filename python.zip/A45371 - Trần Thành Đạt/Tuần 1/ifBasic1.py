#1
print('Nhap so nguyen:')
songuyen = int(input())
if songuyen % 2 == 0:
    print('la so chan')
else:
    print('la so le')

#2
print('nhap so gio lam viec')
sogio = float(input())
if sogio < 40:
    print("LUONG:",sogio * 2,"USD")
else:
    overtime = sogio - 40
    print('Luong:',(overtime*2*1.5)+(40*2),"USD")