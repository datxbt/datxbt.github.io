soDien = int(input("NHAP SO DIEN (KW): "))

if soDien <= 100:
    tien = soDien * 450

elif soDien <= 200:
    tien = 100 * 450 + (soDien - 100) * 600

elif soDien <= 300:
    tien = 100 * 450 + 100 * 600 + (soDien - 200) * 750

elif soDien <= 500:
    tien = 100 * 450 + 100 * 600 + 100 * 750 + (soDien - 300) * 900

elif soDien <= 1000:
    tien = 100 * 450 + 100 * 600 + 100 * 750 + 200 * 900 + (soDien - 500) * 1000

else:
    tien = 100 * 450 + 100 * 600 + 100 * 750 + 200 * 900 + 500 * 1000 + (soDien - 1000) * 1200

thueVAT = tien * 0.1
tongTien = tien + thueVAT

print("SO TIEN PHAI NOP (TRUOC THUE VAT):", tien, "VND")
print("THUE VAT 10%:", thueVAT, "VND")
print("SO TIEN PHAI NOP (SAU THUE VAT):", tongTien, "VND")
