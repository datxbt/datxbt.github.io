soPhut = int(input("Nhap so phut goi: "))

thueBao = 27000
tienCuoc = 0

if soPhut <= 100:
    tienCuoc = soPhut * 120
elif soPhut <= 200:
    tienCuoc = 100 * 120 + (soPhut - 100) * 110
elif soPhut <= 300:
    tienCuoc = 100 * 120 + 100 * 110 + (soPhut - 200) * 100
elif soPhut <= 400:
    tienCuoc = 100 * 120 + 100 * 110 + 100 * 100 + (soPhut - 300) * 80
else:
    tienCuoc = 100 * 120 + 100 * 110 + 100 * 100 + 100 * 80 + (soPhut - 400) * 40

tongCuoc = thueBao + tienCuoc

vat = tongCuoc * 10 / 100
phiVienThong = tongCuoc * 5 / 100
tongThue = vat + phiVienThong

thanhTien = tongCuoc + tongThue

print("So phut goi:", soPhut)
print("Tien thue bao:", thueBao)
print("Tien cuoc goi:", tienCuoc)
print("Tong cuoc:", tongCuoc)
print("Tien thue va phi:", tongThue)
print("Tong tien phai tra:", thanhTien)
