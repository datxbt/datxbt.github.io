#1
print('Nhap so nguyen:')
soNguyen = int(input())
if soNguyen % 3 == 0:
    print('So chia het cho 3')
else:
    print('So khong chia het cho 3')

#2
print('Nhap so nguyen:')
soNguyen2 = int(input())
if soNguyen2 % 7 == 0:
    print('So chia het cho 7')
else:
    print('So khong chia het cho 7')