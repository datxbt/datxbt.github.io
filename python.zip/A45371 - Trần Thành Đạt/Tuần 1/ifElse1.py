print('NHAP LUONG NHAN VIEN')
luong = int(input())
if luong >= 500:
    print('SO TIEN THUE BAN PHAI NOP LA: 20')
else:
    print('BAN KHONG PHAI NOP THUE')