a = 3.6
b = 4.4
g = 5.4
c = a + b
d = a - b
e = a * b
f = a / b
print(c, d, e, f)

# HÌNH CHỮ NHẬT
print("NHAP CHIEU DAI:")
dai = float(input())
print("NHAP CHIEU RONG:")
rong = float(input())

chuvihcn = (dai + rong) * 2
dientichhcn = dai * rong

print("CHU VI HINH CHU NHAT:", chuvihcn)
print("DIEN TICH HINH CHU NHAT:", dientichhcn)


# HÌNH TAM GIÁC
print("NHAP CANH 1 CUA TAM GIAC:")
canh1 = float(input())
print("NHAP CANH 2 CUA TAM GIAC:")
canh2 = float(input())
print("NHAP CANH 3 CUA TAM GIAC:")
canh3 = float(input())

print("NHAP CHIEU CAO CUA TAM GIAC:")
cao = float(input())

chuvitg = canh1 + canh2 + canh3
dientichtg = (canh1 * cao) / 2

print("CHU VI HINH TAM GIAC:", chuvitg)
print("DIEN TICH HINH TAM GIAC:", dientichtg)


# HÌNH TRÒN
print("NHAP BAN KINH HINH TRON:")
r = float(input())

pi = 3.14
chuvitron = 2 * pi * r
dientichtron = pi * r * r

print("CHU VI HINH TRON:", chuvitron)
print("DIEN TICH HINH TRON:", dientichtron)


# HÌNH VUÔNG
print("NHAP CANH HINH VUONG:")
canh = float(input())

chuvihv = canh * 4
dientichhv = canh * canh

print("CHU VI HINH VUONG:", chuvihv)
print("DIEN TICH HINH VUONG:", dientichhv)


# HÌNH THANG
print("NHAP DAY LON CUA HINH THANG:")
daylon = float(input())

print("NHAP DAY NHO CUA HINH THANG:")
daynho = float(input())

print("NHAP CANH BEN 1 CUA HINH THANG:")
canhben1 = float(input())

print("NHAP CANH BEN 2 CUA HINH THANG:")
canhben2 = float(input())

print("NHAP CHIEU CAO CUA HINH THANG:")
caothang = float(input())

chuvihinhthang = daylon + daynho + canhben1 + canhben2
dientichhinhthang = ((daylon + daynho) * caothang) / 2

print("CHU VI HINH THANG:", chuvihinhthang)
print("DIEN TICH HINH THANG:", dientichhinhthang)
