import math
class ChuviDienTich:
    def HinhChuNhat(self):
        self.dai = int(input('Nhap chieu dai HCN: '))
        self.rong = int(input('Nhap chieu rong HCN: '))
        print('Chu vi HCN la: ', (self.dai + self.rong) * 2)
        print('Dien tich HCN la: ', self.dai * self.rong)

    def HinhVuong(self):
        self.canh = int(input('Nhap do dai canh HV: '))
        print('Chu vi HVuong la: ', self.canh * 4)
        print('Dien tich HVuong la: ', self.canh * self.canh)

    def HinhTron(self):
        self.r = int(input('Nhap ban kinh (r):'))
        print('Chu vi HTron la: ',self.r * 2 * 3.14)
        print('Dien tich HTron la: ', self.r * self.r * 3.14)

    def HinhTamGiac(self):
        self.a = int(input('Nhap chieu dai canh A: '))
        self.b = int(input('Nhap chieu dai canh B: '))
        self.c = int(input('Nhap chieu dai canh C: '))
        print('Chu vi HTG la: ',self.a + self.b + self.c)
        p = (self.a + self.b + self.c) / 2
        print('Dien tich HTC la: ',math.sqrt(p * (p - self.a) * (p - self.b) * (p - self.c)))

CVDT = ChuviDienTich()
CVDT.HinhChuNhat()
CVDT.HinhTamGiac()
CVDT.HinhTron()
CVDT.HinhVuong()