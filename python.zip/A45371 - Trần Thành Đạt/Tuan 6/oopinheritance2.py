class Vehicle:
    def __init__(self, name, maxPassengers, maxSpeed):
        self.name = name
        self.maxPassengers = maxPassengers
        self.maxSpeed = maxSpeed

    def display(self):
        print('name =', self.name, '| maxPassengers =', self.maxPassengers,
              '| maxSpeed =', self.maxSpeed)


class LandVehicle(Vehicle):
    def __init__(self, name, maxPassengers, maxSpeed, numWheels):
        # goi constructor lop cha de gan name, maxPassengers, maxSpeed
        super().__init__(name, maxPassengers, maxSpeed)
        self.numWheels = numWheels

    def drive(self):
        print('Driving land vehicle')


class SeaVessel(Vehicle):
    def __init__(self, name, maxPassengers, maxSpeed, displacement):
        super().__init__(name, maxPassengers, maxSpeed)
        self.displacement = displacement

    def launch(self):
        print('Launching sea vessel')


class Jeep(LandVehicle):
    def __init__(self, name, maxPassengers, maxSpeed, numWheels):
        super().__init__(name, maxPassengers, maxSpeed, numWheels)

    def soundHorn(self):
        print('Sound horn beep beep')


class Frigate(SeaVessel):
    def __init__(self, name, maxPassengers, maxSpeed, displacement):
        super().__init__(name, maxPassengers, maxSpeed, displacement)

    def fireGun(self):
        print('Fire gun boom boom')


class Hovercraft(LandVehicle, SeaVessel):
    def __init__(self, name, maxPassengers, maxSpeed, numWheels, displacement):
        # Da ke thua: 2 lop cha co tham so khac nhau, nen goi thang
        # Vehicle.__init__ roi tu gan thuoc tinh rieng cua tung lop cha.
        Vehicle.__init__(self, name, maxPassengers, maxSpeed)
        self.numWheels = numWheels
        self.displacement = displacement

    def enterLand(self):
        print("enter land")

    def enterSea(self):
        print('enter sea')


jeepwrangler = Jeep("Jeep Wrangler", 5, 150, 4)
jeepwrangler.display()
jeepwrangler.drive()
jeepwrangler.soundHorn()

frigate123 = Frigate("Frigate 123", 5, 160, 10)
frigate123.display()
frigate123.launch()
frigate123.fireGun()

hv = Hovercraft("HV123", 5, 130, 5, 10)
hv.display()
print('numWheels =', hv.numWheels, '| displacement =', hv.displacement)
hv.enterLand()
hv.enterSea()
