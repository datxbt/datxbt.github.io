class Calculator:
    def add(self):
        self.a = int(input("add a ="))
        self.b = int(input("add b ="))
        c = self.a + self.b
        print('Tong cua', self.a, 'va', self.b, 'la:', c)

    def minus(self):
        self.a = int(input('minus a ='))
        self.b = int(input('minus b ='))
        c = self.a - self.b
        print('Hieu cua', self.a, 'va', self.b, 'la:', c)

    def divide(self):
        self.a = int(input('div a ='))
        self.b = int(input('div b ='))
        c = self.a / self.b
        print('Thuong cua', self.a, 'va', self.b, 'la:', c)

    def multiple(self):
        self.a = int(input('mult a ='))
        self.b = int(input('mult b ='))
        c = self.a * self.b
        print('Tich cua', self.a, 'va', self.b, 'la:', c)

    def factorial(self):
        self.a = int(input('Giai thua cua?:'))
        self.kq = 1
        for i in range (1,self.a+1):
            self.kq*=i
            i+=1
        print("Giai thua cua",self.a, 'la:',self.kq)

calc = Calculator()
calc.add()
calc.minus()
calc.divide()
calc.multiple()
calc.factorial()