""" class NhanVien:
    def __init__(self, id, name, salary):
        self.ma = id
        self.ten = name
        self.luong = salary

    def display(self):
        print('id = ', self.ma)
        print('ten = ', self.ten)
        print('luong = ', self.luong)


nv1 = NhanVien(1, 'Tieu Vy', 5000)
nv1.display()

nv2 = NhanVien(2, 'Mai Ngoc', 3000)
nv2.display() """

class Person:
    def __init__(self, name, address, age):
        self.name = name
        self.address = address
        self.age = age

    def inputDetails(self, name, address, age):
        self.name = name
        self.address = address
        self.age = age

    def displayDetails(self):
        print('name = ', self.name)
        print('age = ', self.age)
        print('address: ', self.address)

p1 = Person('Tuan', "Ha Noi", 21)
p1.displayDetails()
p1.inputDetails('Minh', "Quang Ninh", 23)
p1.displayDetails()