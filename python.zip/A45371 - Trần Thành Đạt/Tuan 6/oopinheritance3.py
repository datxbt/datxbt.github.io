import math


class HinhHoc:
    def dienTich(self):
        return 0


class HinhChuNhat(HinhHoc):
    def __init__(self, chieuRong, chieuDai):
        self.chieuRong = chieuRong
        self.chieuDai = chieuDai

    def dienTich(self):
        return self.chieuRong * self.chieuDai


class HinhVuong(HinhHoc):
    def __init__(self, canh):
        self.canh = canh

    def dienTich(self):
        return self.canh * self.canh


class HinhTron(HinhHoc):
    def __init__(self, banKinh):
        self.banKinh = banKinh

    def dienTich(self):
        return math.pi * self.banKinh ** 2


class HinhThang(HinhHoc):
    def __init__(self, daiLon, daiNho, chieuCao):
        self.daiLon = daiLon
        self.daiNho = daiNho
        self.chieuCao = chieuCao

    def dienTich(self):
        return (self.daiLon + self.daiNho) * self.chieuCao / 2


while True:
    print("\n1. Diện tích hình chữ nhật")
    print("2. Diện tích hình vuông")
    print("3. Diện tích hình tròn")
    print("4. Diện tích hình thang")
    print("5. Thoát")
    chon = input("Chọn: ")

    if chon == "1":
        a = float(input("Chiều rộng: "))
        b = float(input("Chiều dài: "))
        print("Diện tích =", HinhChuNhat(a, b).dienTich())
    elif chon == "2":
        a = float(input("Cạnh: "))
        print("Diện tích =", HinhVuong(a).dienTich())
    elif chon == "3":
        r = float(input("Bán kính: "))
        print("Diện tích =", HinhTron(r).dienTich())
    elif chon == "4":
        a = float(input("Đáy lớn: "))
        b = float(input("Đáy nhỏ: "))
        h = float(input("Chiều cao: "))
        print("Diện tích =", HinhThang(a, b, h).dienTich())
    elif chon == "5":
        break