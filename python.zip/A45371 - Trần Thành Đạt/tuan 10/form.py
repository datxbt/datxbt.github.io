from tkinter import Tk, Menu

# form chinh
root = Tk()
root.geometry('320x150')
root.title('Menu Demo')

# khoi tao menubar
menubar = Menu(root)
root.config(menu=menubar)

# tao ra file_menu
file_menu = Menu(
    menubar,
    tearoff=0
)

# add menu items vao File menu
file_menu.add_command(label='New')
file_menu.add_command(label='Open...')
file_menu.add_command(label='Close')
file_menu.add_separator()

# them mot submenu
sub_menu = Menu(file_menu, tearoff=0)
sub_menu.add_command(label='Keyboard Shortcuts')
sub_menu.add_command(label='Color Themes')

# them File menu vao menubar
file_menu.add_cascade(
    label="Preferences",
    menu=sub_menu
)

# Them phan tu Exit menu item
file_menu.add_separator()
file_menu.add_command(
    label='Exit',
    command=root.destroy
)

menubar.add_cascade(
    label="File",
    menu=file_menu,
    underline=0
)

# Tao Help menu
help_menu = Menu(
    menubar,
    tearoff=0
)

help_menu.add_command(label='Welcome')
help_menu.add_command(label='About...')

# Them Help menu vao menubar
menubar.add_cascade(
    label="Help",
    menu=help_menu,
    underline=0
)

root.mainloop()