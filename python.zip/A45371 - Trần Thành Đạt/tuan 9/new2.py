import tkinter as tk

window = tk.Tk()

window.title("login")
window.geometry("400x400")

label1 = tk.Label(window, text= "please login")
label1.grid(column=0, row=0)


label2 = tk.Label(window, text= "num1:")
label2.grid(column=0, row=1, sticky= "w")
entry2= tk.Entry(window)
entry2.grid(column=1, row=1)

label3 = tk.Label(window, text= "num2:")
label3.grid(column=0, row=2, sticky= "w")
entry3= tk.Entry(window)
entry3.grid(column=1, row=2)

def tinh():
    total = int(entry2.get()) + int(entry3.get())
    entry4.insert(0, total)

    entry2.delete(0)
    entry3.delete(0)


label4 = tk.Label(window, text= "kq:")
label4.grid(column=0, row=3, sticky= "w")
entry4= tk.Entry(window)
entry4.grid(column=1, row=3)



button1 = tk.Button(window, text= "tinh", command= tinh)
button1.grid(column= 0, row= 4, sticky= "w")

window.mainloop()