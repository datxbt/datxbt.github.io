import tkinter as tk

window = tk.Tk()

window.title("Hello python")
window.geometry("400x400")

def open_popup():
    popup = tk.Toplevel(window)

    popup.title("Hello python")
    popup.geometry("400x400")

    def printout():
        print("last name", entry1.get())
        print("first name", entry2.get())
        print("job", entry3.get())
        print("country", entry4.get())

    label1 = tk.Label(popup, text= "last name")
    label1.grid(column= 1, row= 0, pady= 5, padx= 0)
    entry1 = tk.Entry(popup)
    entry1.insert(0, "klein")
    entry1.grid(column= 2, row= 0, pady= 5, padx= 0)

    label2 = tk.Label(popup, text= "first name")
    label2.grid(column= 1, row= 1, pady= 5, padx= 0)
    entry2 = tk.Entry(popup)
    entry2.insert(0, "bernd")
    entry2.grid(column= 2, row= 1, pady= 5, padx= 0)

    label3 = tk.Label(popup, text= "job")
    label3.grid(column= 1, row= 2, pady= 5, padx= 0)
    entry3 = tk.Entry(popup)
    entry3.insert(0, "trainer")
    entry3.grid(column= 2, row= 2, pady= 5, padx= 0)

    label4 = tk.Label(popup, text= "country")
    label4.grid(column= 1, row= 3, pady= 5, padx= 0)
    entry4 = tk.Entry(popup)
    entry4.insert(0, "germany")
    entry4.grid(column= 2, row= 3, pady= 5, padx= 0)

    button1 = tk.Button(popup, text= "show", command= printout)
    button1.grid(column= 1, row= 4, pady= 0, padx= 0)

    button2 = tk.Button(popup, text= "quit", command= popup.destroy)
    button2.grid(column= 2, row= 4, pady= 0, padx= 0, sticky ="w")



label = tk.Label(window, text="this is a label widget", fg= "red", font=("Arial", 20))
label.pack(pady= (60,20))

button = tk.Button(window, text= "this is button widget", fg = "blue", font=("Arial", 15), command= open_popup)
button.pack(pady= 20)

entry = tk.Entry(window, font= ("Arial", 15), bd= 6)
entry.insert(0, "this is entry widget")
entry.pack(pady = 20)

window.mainloop()