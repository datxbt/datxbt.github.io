import tkinter as tk

window = tk.Tk()

window.title("registration form")
window.geometry("300x400")

country_var = tk.StringVar()
country_var.set("India")

# moi nhom Radiobutton dung chung 1 bien; moi Checkbutton co 1 bien rieng
gender_var = tk.StringVar(value="male")
english_var = tk.IntVar()
german_var = tk.IntVar()


def submit():
    languages = []
    if english_var.get() == 1:
        languages.append("english")
    if german_var.get() == 1:
        languages.append("german")
    print("full name:", entry2.get())
    print("email:", entry3.get())
    print("gender:", gender_var.get())
    print("country:", country_var.get())
    print("language:", ", ".join(languages))

label1 = tk.Label(window, text= "registration form", font= ("Arial", 20))
label1.grid(column= 0, row= 0, columnspan= 3, pady= 20)

label2 = tk.Label(window, text= "full name")
label2.grid(column= 0, row= 1, pady= 5, sticky= "w")
entry2 = tk.Entry(window)
entry2.grid(column= 1, row= 1, columnspan= 2, pady= 5)

label3 = tk.Label(window, text= "email")
label3.grid(column= 0, row= 2, pady= 5, sticky= "w")
entry3 = tk.Entry(window)
entry3.grid(column= 1, row= 2, columnspan= 2, pady= 5)

label4 = tk.Label(window, text= "gender")
label4.grid(column= 0, row= 3, pady= 5, sticky= "w")
radio4a = tk.Radiobutton(window, text= "male", variable= gender_var, value= "male")
radio4a.grid(column= 1, row= 3, pady= 5, sticky= "w")
radio4b = tk.Radiobutton(window, text= "female", variable= gender_var, value= "female")
radio4b.grid(column= 2, row= 3, pady= 5, sticky= "w")

label5 = tk.Label(window, text= "country")
label5.grid(column= 0, row= 4, pady= 5, sticky= "w")
menu5 = tk.OptionMenu(window,country_var, "India", "Vietnam", "Germany", "USA")
menu5.grid(column= 1, row= 4, columnspan= 2, pady= 5)

label6 = tk.Label(window, text= "language")
label6.grid(column= 0, row= 5, pady= 5, sticky= "w")
check6a = tk.Checkbutton(window, text= "english", variable= english_var)
check6a.grid(column= 1, row= 5, pady= 5, sticky= "w")
check6b = tk.Checkbutton(window, text= "german", variable= german_var)
check6b.grid(column= 2, row= 5, pady= 5, sticky= "w")

button7 = tk.Button(window, text= "submit", bg= "black", fg= "white", width= 20, command= submit)
button7.grid(column= 0, row= 6, columnspan= 3, pady= 20)

window.mainloop()