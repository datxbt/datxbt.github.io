def arearectangle (a, b):
    return a*b
def square (x):
    return x*x
def factorial (x):
    kq = 1
    for i in range (1, x+1):
        kq *= i
    return kq

a = int(input("Nhap a:"))
b = int(input("Nhap b:"))
x = int(input("Nhap x:"))

print("dien tich hinh chu nhat: " + str(arearectangle(a,b)))
print("binh phuong cua x: " + str(square(x)))
print("giai thua cua x: " + str(factorial(x)))
