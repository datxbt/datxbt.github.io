# Dat ten "add" thay vi "sum" de khong de len ham sum() co san cua Python
def add(a,b):
    return a+b
def sub(a,b):
    return a-b
def div(a,b):
    return a/b
def mult(a,b):
    return a*b

a = int(input("nhap a:"))
b = int(input("nhap b:"))

print("tong cua a,b la: " + str(add(a,b)))
print("hieu cua a,b la: " + str(sub(a,b)))
print("thuong cua a,b la: " + str(div(a,b)))
print("tich cua a,b la: " + str(mult(a,b)))
