def tinhGiaithua(n):
    kq = 1
    for i in range(1, n+1):
        kq *= i
    return kq

n = int(input("Nhap n: "))

print("giai thua: " + str(tinhGiaithua(n)))