def largest (a,b,c):
    if a>=b and a>=c:
        return a
    elif b>=a and b>=c:
        return b
    else: return c

def avg (a,b,c,d):
    return (a+b+c+d)/4

a = float(input("Nhap a:"))
b = float(input("Nhap b:"))
c = float(input("Nhap c:"))
d = float(input("Nhap d:"))

print("so lon nhat (a,b,c): " + str(largest(a,b,c)))
print("trung binh cong (a,b,c,d): " + str(avg(a,b,c,d)))
