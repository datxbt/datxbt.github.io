def tinh_diem(chuyen_can, qua_trinh, cuoi_ky):
    return chuyen_can * 0.1 + qua_trinh * 0.3 + cuoi_ky * 0.6


def xeploai(diem1, diem2, diem3):
    trung_binh = (diem1 + diem2 + diem3) / 3

    if trung_binh >= 8.5:
        loai = "A"
    elif trung_binh >= 7.0:
        loai = "B"
    elif trung_binh >= 5.5:
        loai = "C"
    elif trung_binh >= 4.0:
        loai = "D"
    else:
        loai = "F"

    return trung_binh, loai


# Tính điểm 3 học phần
lap_trinh_co_so = tinh_diem(8, 7, 9)
tieng_anh = tinh_diem(7, 8, 8)
phan_tich_du_lieu = tinh_diem(9, 6, 8)

# In kết quả
print("Lập trình cơ sở:", lap_trinh_co_so)
print("Tiếng Anh:", tieng_anh)
print("Phân tích dữ liệu:", phan_tich_du_lieu)

# Xếp loại
diem_tb, loai = xeploai(lap_trinh_co_so, tieng_anh, phan_tich_du_lieu)

print("Điểm trung bình:", round(diem_tb, 2))
print("Xếp loại:", loai)